"""
Ограничение типов рынков (options.fetchMarkets) и совместимость со старыми ccxt.

Реальные случаи (Windows, ccxt 4.5.52 — BUGFIXES #47, #48):

* hyperliquid понимает только формат {"types": [...]}; на голом списке
  ["swap"] в 4.5.52 safe_list возвращает None (без дефолта) и fetch_markets
  падает с `TypeError: object of type 'NoneType' has no len()`. TypeError не
  считался «опционной» ошибкой → отката на полную загрузку не было → биржа
  вечно висела в revive-лупе.
* binance/bybit зовут перпетуалы 'linear'/'inverse', а не 'swap' — список
  ["swap"] отвергался ExchangeError и ccxt грузил ВСЕ рынки (bybit: 3667
  объектов метаданных вместо ~1400).
* OKX: в снапшоте books-l2-tbt элемент data[0] не содержит instId →
  symbol=None → при расхождении чексуммы ccxt 4.5.52 падал с TypeError
  (None + str) внутри колбэка asyncio: future не резолвился и не реджектился,
  поток стакана висел, консоль спамилась «Exception in callback».
"""
import asyncio
import copy

import ccxt
import pytest

import app.collector as collector_mod
from app.collector import (ExchangeCollector, apply_ccxt_compat,
                           restrict_fetch_markets)
from app.config import ExchangeConfig, Settings
from app.state import STORE


@pytest.fixture
def settings():
    s = Settings()
    s.mode = "replay"
    s.load_retries = 1          # без sleep между попытками в тестах
    s.request_timeout = 20_000
    s.revive_interval = 15.0
    s.fetch_ohlcv = False
    return s


def make_collector(settings, ex_id, label, market):
    cfg = ExchangeConfig(ex_id, label, market, top_n=5, books=2)
    return ExchangeCollector(cfg, settings)


# --------------------------------------------------------------------------
# Формат опции fetchMarkets
# --------------------------------------------------------------------------
@pytest.mark.parametrize("ex_id,want,expected", [
    # перпетуалы: у каждого семейства своё имя типа
    ("binanceusdm", "swap", {"types": ["linear"]}),
    ("binance", "swap", {"types": ["linear", "inverse"]}),
    ("bybit", "swap", {"types": ["linear", "inverse"]}),
    ("okx", "swap", {"types": ["swap"]}),
    ("gate", "swap", {"types": ["swap"]}),
    ("mexc", "swap", {"types": ["swap"]}),
    ("aster", "swap", {"types": ["swap"]}),
    # hip3 (билдерские перпы) входят в дефолт ccxt — не теряем их
    ("hyperliquid", "swap", {"types": ["swap", "hip3"]}),
    # спот везде называется одинаково
    ("binance", "spot", {"types": ["spot"]}),
    ("bybit", "spot", {"types": ["spot"]}),
    ("okx", "spot", {"types": ["spot"]}),
    ("gate", "spot", {"types": ["spot"]}),
    ("hyperliquid", "spot", {"types": ["spot"]}),
])
def test_restrict_fetch_markets_mapping(ex_id, want, expected):
    assert restrict_fetch_markets(ex_id, want) == expected


def test_restrict_option_is_dict_at_load(settings):
    """
    Ограничение передаётся словарём {"types": [...]}, а не списком.

    Именно список ломал hyperliquid в ccxt 4.5.52 (TypeError) и молча
    игнорировался Gate (полная загрузка 6827 объектов вместо ~2200).
    """
    collector = make_collector(settings, "bybit", "RT-bybit", "swap")
    captured = []

    async def fake_load(reload=False):
        captured.append(copy.deepcopy(collector.ex.options.get("fetchMarkets")))
        collector.ex.markets = {"BTC/USDT:USDT": {"swap": True}}

    collector.ex.load_markets = fake_load
    assert asyncio.run(collector._load_markets()) is True
    assert captured == [{"types": ["linear", "inverse"]}], \
        "bybit swap должен грузиться одним проходом с dict-опцией"


# --------------------------------------------------------------------------
# Откат на полную загрузку
# --------------------------------------------------------------------------
def test_typeerror_on_restrict_falls_back_to_full_load(settings):
    """
    Регрессия ccxt 4.5.52 + hyperliquid: TypeError на ограниченной загрузке
    обязан приводить к откату, а не к вечному revive-лупу.
    """
    collector = make_collector(settings, "hyperliquid", "RT-hl", "swap")
    calls = []

    async def fake_load(reload=False):
        opt = copy.deepcopy(collector.ex.options.get("fetchMarkets"))
        calls.append(opt)
        if opt == {"types": ["swap", "hip3"]}:
            # ровно та ошибка, что прилетела с машины пользователя
            raise TypeError("object of type 'NoneType' has no len()")
        collector.ex.markets = {
            "BTC/USDT:USDT": {"swap": True},
            "BTC/USDT": {"spot": True},
        }

    collector.ex.load_markets = fake_load
    assert asyncio.run(collector._load_markets()) is True
    assert len(calls) == 2, "после TypeError должна быть вторая (полная) загрузка"
    # второй вызов — с восстановленным дефолтом ccxt (spot+swap+hip3)
    assert "spot" in calls[1]["types"]
    status = STORE.status("RT-hl")
    assert status.get("state") != "error"


def test_exchange_error_on_restrict_falls_back(settings):
    """Прежнее поведение сохранено: ExchangeError на опции → полная загрузка."""
    collector = make_collector(settings, "bybit", "RT-bybit2", "swap")
    calls = []

    async def fake_load(reload=False):
        opt = copy.deepcopy(collector.ex.options.get("fetchMarkets"))
        calls.append(opt)
        if opt == {"types": ["linear", "inverse"]}:
            raise ccxt.ExchangeError(
                'bybit fetchMarkets() self.options fetchMarkets "linear" '
                "is not a supported market type")
        collector.ex.markets = {"BTC/USDT:USDT": {"swap": True}}

    collector.ex.load_markets = fake_load
    assert asyncio.run(collector._load_markets()) is True
    assert len(calls) == 2


def test_network_error_on_restrict_does_not_fall_back(settings):
    """
    Сетевая ошибка — не повод для второй загрузки: причина в доступности
    API, а не в опции. Пробуем только load_retries раз и уходим в ошибку.
    """
    settings.load_retries = 2
    collector = make_collector(settings, "okx", "RT-okx-net", "swap")
    calls = []

    async def fake_load(reload=False):
        calls.append(1)
        raise ccxt.NetworkError("okx GET https://www.okx.com/... timed out")

    collector.ex.load_markets = fake_load
    # sleep между ретраями — мокаем, чтобы тест не ждал 2 c
    async def no_sleep(_):
        return None
    collector_mod.asyncio.sleep = no_sleep
    try:
        assert asyncio.run(collector._load_markets()) is False
    finally:
        import importlib
        collector_mod.asyncio = importlib.import_module("asyncio")
    assert len(calls) == settings.load_retries, \
        "полную загрузку после сетевой ошибки пробовать не должны"
    assert STORE.status("RT-okx-net").get("state") == "error"


# --------------------------------------------------------------------------
# OKX: чексумма стакана отключена (ccxt < 4.5.85 падал на ней с TypeError)
# --------------------------------------------------------------------------
def test_okx_collector_disables_book_checksum(settings):
    collector = make_collector(settings, "okx", "RT-okx-cs", "swap")
    assert collector.ex.options["watchOrderBook"]["checksum"] is False
    # именно эта опция читается gate-ом `if checksum:` в handle_order_book_message
    assert collector.ex.handle_option("watchOrderBook", "checksum", True) is False


def test_other_exchanges_checksum_untouched(settings):
    collector = make_collector(settings, "bybit", "RT-bybit-cs", "swap")
    wob = collector.ex.options.get("watchOrderBook") or {}
    assert wob.get("checksum") is not False, \
        "отключение чексуммы — точечная мера только для OKX"


# --------------------------------------------------------------------------
# Compat-патч orderbook_checksum_message
# --------------------------------------------------------------------------
def test_checksum_message_none_safe_and_idempotent(monkeypatch):
    monkeypatch.setattr(collector_mod, "_ccxt_compat_applied", False)
    assert apply_ccxt_compat() is True
    assert apply_ccxt_compat() is False, "повторно патчить не должны"

    ex = ccxt.okx()
    # до патча здесь был TypeError: None + '  = False'
    assert ex.orderbook_checksum_message(None) == "?  = False"
    assert ex.orderbook_checksum_message("BTC/USDT:USDT") == "BTC/USDT:USDT  = False"
    # наследуется и асинхронным/pro-классом (общий базовый Exchange)
    import ccxt.pro
    pro_ex = ccxt.pro.okx()
    assert pro_ex.orderbook_checksum_message(None) == "?  = False"


def test_collector_init_applies_compat(settings):
    """Каждый созданный коллектор гарантирует наличие патча в процессе."""
    monkey_flag_before = collector_mod._ccxt_compat_applied
    make_collector(settings, "gate", "RT-gate-init", "spot")
    assert collector_mod._ccxt_compat_applied is True
    assert getattr(ccxt.Exchange.orderbook_checksum_message, "_none_safe", False)
    assert monkey_flag_before in (True, False)  # не ломаем состояние других тестов
