"""
Сборщик рыночных данных.

Одна биржа = один ExchangeCollector = один набор asyncio-тасков:
  * watch_ticker / watch_trades / watch_order_book  — WebSocket (ccxt.pro)
  * периодический REST-срез тикеров (24h)           — объёмы, high/low, count
  * периодическая подкачка 1m-свечей                — NATR, мульти-ТФ доходности
  * bulk-запрос OI/funding нативным API биржи       — один вызов на всю биржу

Ключевая идея «горячего набора»: физически стримить 18 000 инструментов
невозможно (и не нужно), поэтому мы держим top_n по объёму и раз в
HOT_ROTATE секунд пересобираем список — монеты «в игре» сами всплывают
в стрим, протухшие выпадают.
"""
from __future__ import annotations

import asyncio
import contextlib
import json
import logging
import os
import sys
import time
import urllib.parse
import urllib.request
from typing import Optional

import ccxt
import ccxt.pro as ccxtpro

from .config import ExchangeConfig, Settings
from .metrics import set_reference_prices
from .state import STORE

log = logging.getLogger("collector")

HOT_ROTATE = 45.0        # сек: как часто пересчитываем «горячий набор»
# Фокус-режим (см. app/focus.py) отдаёт коллектору готовый список монет и
# ждёт, что подписки изменятся СРАЗУ, а не через HOT_ROTATE. Поэтому ротация
# спит на Event и просыпается по set_focus(). Без этого первые графики после
# включения фокуса появлялись бы только через 45 секунд.
FOCUS_ROTATE_DELAY = 0.4
ROTATE_START_DELAY = 3.0  # сек: даём бирже загрузить тикеры до первой ротации
TRADES_STREAM_N = 120    # сколько символов стримим по сделкам (дельта/CVD)
FUNDING_REFRESH = 30.0   # сек
CANDLES_TTL = 12.0       # сек: время жизни кэша свечей для графиков
MAX_STREAM_FAILS = 5     # подряд идущих отказов биржи → гасим поток по символу
FAIL_WINDOW = 120.0      # сек: окно, внутри которого отказы считаются «подряд»
CORRELATED_FAIL_WINDOW = 2.0   # сек: если все отказы уложились сюда — это обрыв соединения
BAN_TTL = 600.0          # сек: через сколько амнистировать забаненные символы
PAUSED_TICKER_REFRESH = 120.0   # сек: период опроса тикеров у биржи вне фокуса
FOCUS_OHLCV_CONCURRENCY = 24    # параллельных запросов свечей при пересчёте отбора

# Binance-совместимый bulk-эндпоинт funding (поле lastFundingRate по всем контрактам)
# Точечный OI через нативный API — там, где ccxt fetchOpenInterest не реализовал.
# Обе биржи отвечают в Binance-формате: {"symbol":..., "openInterest": "<в базовой монете>"}
NATIVE_OI_URL = {
    "binanceusdm": "https://fapi.binance.com/fapi/v1/openInterest?symbol=",
    "aster": "https://fapi.asterdex.com/fapi/v1/openInterest?symbol=",
}

PREMIUM_INDEX_URLS = {
    "binanceusdm": "https://fapi.binance.com/fapi/v1/premiumIndex",
    "aster": "https://fapi.asterdex.com/fapi/v1/premiumIndex",
}
SNAPSHOT_EVERY = 300.0   # сек: дамп снапшота на диск (для replay-режима)


# --------------------------------------------------------------------------
# Классификация ошибок загрузки: от неё зависит, повторять ли запрос
# --------------------------------------------------------------------------
_OPTION_ERROR_HINTS = ("fetchMarkets", "is not a supported market", "not supported")


# --------------------------------------------------------------------------
# Ограничение загружаемых типов рынков (options.fetchMarkets)
# --------------------------------------------------------------------------
# Канонический формат опции — словарь {"types": [...]}; его понимают все
# биржи, которые вообще поддерживают ограничение (проверено на ccxt 4.5.52
# и 4.5.85). Голый список ["swap"] — только backward-compat путь: Gate его
# молча игнорирует (грузит всё), а hyperliquid в 4.5.52 на нём падает с
# TypeError: object of type 'NoneType' has no len() (BUGFIXES #47).
# Имена типов тоже различаются: Binance-семейство и Bybit зовут перпетуалы
# 'linear'/'inverse', OKX/Gate/Hyperliquid — 'swap'. Aster и MEXC опцию
# игнорируют полностью (всегда грузят все рынки).
_RESTRICT_SWAP_TYPES = {
    "binanceusdm": ["linear"],             # USDⓈ-M: inverse-контрактов нет
    "binance": ["linear", "inverse"],      # на случай конфига binance+swap
    "bybit": ["linear", "inverse"],
    "hyperliquid": ["swap", "hip3"],       # hip3 — билдерские перпы (в дефолте ccxt)
}


def restrict_fetch_markets(exchange_id: str, want: str) -> dict:
    """Значение options.fetchMarkets, чтобы грузить только рынки типа `want`."""
    types = _RESTRICT_SWAP_TYPES.get(exchange_id, ["swap"]) if want == "swap" else ["spot"]
    return {"types": list(types)}


def is_option_error(e: BaseException) -> bool:
    """Биржа отвергла саму опцию fetchMarkets (а не сеть)."""
    if not isinstance(e, (ccxt.ExchangeError, ccxt.NotSupported)):
        return False
    if isinstance(e, (ccxt.NetworkError, ccxt.DDoSProtection, ccxt.RateLimitExceeded)):
        return False
    return any(h.lower() in str(e).lower() for h in _OPTION_ERROR_HINTS)


def is_network_error(e: BaseException) -> bool:
    """Сетевой уровень: DNS, TLS, прокси, таймаут, геоблокировка."""
    return isinstance(e, (ccxt.NetworkError, ccxt.RequestTimeout, ccxt.DDoSProtection))


def _root_cause(e: BaseException) -> Optional[BaseException]:
    """
    Первопричина из цепочки __cause__/__context__.

    ccxt маскирует сетевые ошибки так:
        raise ExchangeNotAvailable(' '.join([id, method, url])) from e
    — в сообщении остаётся ТОЛЬКО URL, а настоящая причина (SSL-ошибка,
    сброс соединения, отказ прокси, gaierror) уходит в сцеплённое исключение.
    Без размотки цепочки все отказы выглядели одинаково («ExchangeNotAvailable:
    <биржа> GET <url>»), и диагноз терялся и в логах, и в doctor.py.
    """
    seen = {id(e)}
    cur = e.__cause__ or e.__context__
    root: Optional[BaseException] = None
    while cur is not None and id(cur) not in seen:
        seen.add(id(cur))
        root = cur
        cur = cur.__cause__ or cur.__context__
    return root


def describe_error(e: BaseException) -> str:
    """
    Человекочитаемая причина. ccxt кладёт в сообщение URL, а настоящую причину
    (getaddrinfo failed, CERTIFICATE_VERIFY_FAILED, 403, tunnel connection failed)
    — в конец строки ИЛИ в __cause__ (см. _root_cause), поэтому короткая обрезка
    показывала только URL.
    """
    raw = " ".join(str(e).split())
    tail = raw[-220:] if len(raw) > 220 else raw
    root = _root_cause(e)
    cause_txt = ""
    if root is not None:
        rtxt = " ".join(str(root).split())
        if rtxt and rtxt != raw:
            cause_txt = f" ← {type(root).__name__}: {rtxt[:200]}"
    hint = ""
    low = (raw + " " + type(e).__name__
           + (" " + type(root).__name__ + " " + str(root) if root is not None else "")).lower()
    if "could not contact dns servers" in low or "clientconnectordnserror" in low:
        # Отдельный класс: системный DNS (getaddrinfo) работает, а aiohttp с
        # aiodns шлёт UDP-запросы к DNS-серверу напрямую и они блокируются.
        # Проверяется ПЕРЕД ssl-веткой: в сообщении ClientConnectorDNSError
        # есть «ssl:default», и без порядка веток причина терялась бы.
        hint = (" — асинхронный DNS-резолвер aiohttp (aiodns) не может достучаться "
                "до DNS-сервера; приложение автоматически использует системный "
                "резолвер (ThreadedResolver), если всё равно не работает — "
                "смените DNS на 1.1.1.1")
    elif "getaddrinfo" in low or "name or service not known" in low or "nodename nor servname" in low:
        hint = " — не резолвится DNS (нет интернета или проблема с DNS)"
    elif "certificate" in low or "ssl" in low or "cert" in low:
        hint = " — проблема с TLS-сертификатами (частый случай на Windows: обновите certifi)"
    elif "tunnel" in low or "proxy" in low or "407" in low:
        hint = " — требуется прокси (задайте HTTPS_PROXY)"
    elif "451" in raw or "403" in raw or "restricted" in low or "not available in your" in low:
        hint = " — биржа блокирует ваш регион (нужен VPN)"
    elif "timed out" in low or "timeout" in low:
        hint = " — таймаут соединения (файрвол/антивирус может блокировать исходящие)"
    elif "actively refused" in low or "connection refused" in low:
        hint = " — соединение отклонено (файролл/антивирус)"
    elif ("forcibly closed" in low or "connection reset" in low or "10054" in low
          or "server disconnected" in low):
        hint = " — соединение оборвала удалённая сторона (DPI/файрвол/антивирус рвёт TCP; на Windows так же выглядит работа через заблокированный прямой выход при включённом системном прокси)"
    return f"{type(e).__name__}: {tail}{cause_txt}{hint}"


# --------------------------------------------------------------------------
# Прокси
# --------------------------------------------------------------------------
PROXY_ENV = ("HTTPS_PROXY", "https_proxy", "HTTP_PROXY", "http_proxy", "ALL_PROXY", "all_proxy")


def proxy_from_env() -> Optional[str]:
    for k in PROXY_ENV:
        v = os.getenv(k)
        if v:
            return v.strip()
    return None


def apply_proxy(opts: dict) -> Optional[str]:
    """
    Проксирование REST и WebSocket одновременно.

    ccxt требует РОВНО ОДНУ настройку на слой, иначе InvalidProxySettings
    «multiple conflicting proxy settings» (проверено живым прогоном на 4.5.85):
      * REST → `httpsProxy`: все URL бирж https, ccxt передаёт значение в
        aiohttp `proxy=` (настоящий forward-прокси, не префикс URL);
      * WS   → `wssProxy`: потоки wss, их ccxt читает отдельной группой
        атрибутов wsProxy/wssProxy/wsSocksProxy через check_ws_proxy_settings().

    Прежняя версия ставила `httpProxy` И `httpsProxy` вместе — современный
    ccxt отвергает эту комбинацию сразу, т.е. PROXY_URL ломал ВСЕ биржи.
    `aiohttp_trust_env` оставлен как страховка для HTTPS_PROXY из окружения.
    """
    url = SETTINGS_PROXY_OVERRIDE or proxy_from_env()
    if not url:
        _warn_windows_system_proxy()
        return None
    opts["aiohttp_trust_env"] = True
    opts["httpsProxy"] = url      # REST (https)
    opts["wssProxy"] = url        # WebSocket (wss)
    log.info("используется прокси %s (REST: httpsProxy, WS: wssProxy)", url)
    return url


_warned_system_proxy = False


def _warn_windows_system_proxy() -> None:
    """
    Одноразовое предупреждение про системный прокси Windows.

    Ловушка, в которую попал пользователь: VPN-приложение (Clash, v2rayN,
    Outline и т.п.) включает системный прокси в реестре Windows. Браузер и
    urllib (через getproxies) ходят через него, а aiohttp/ccxt — напрямую,
    и прямой выход заблокирован. Снаружи это выглядит как «все биржи
    ExchangeNotAvailable за 0.3 c», хотя «прямые» запросы в докторе проходят.
    """
    global _warned_system_proxy
    if sys.platform != "win32" or _warned_system_proxy:
        return
    _warned_system_proxy = True
    try:
        from .preflight import windows_system_proxy
        enabled, server, pac = windows_system_proxy()
    except Exception:
        return
    if enabled and server:
        log.warning(
            "в Windows включён системный прокси (%s), но PROXY_URL/HTTPS_PROXY не заданы: "
            "браузер и urllib ходят через него, а ccxt подключается напрямую и не "
            'подключается. Исправление:  $env:PROXY_URL="%s"; python run.py',
            server, server)
    elif pac:
        log.warning(
            "в Windows задано автоматическое конфигурирование прокси (PAC: %s), но "
            "PROXY_URL не задан. Если биржи не подключаются — пропишите порт локального "
            'VPN-прокси вручную:  $env:PROXY_URL="http://127.0.0.1:PORT"; python run.py',
            pac)


# --------------------------------------------------------------------------
# DNS-резолвер aiohttp
# --------------------------------------------------------------------------
_dns_resolver_logged = False


def apply_dns_resolver() -> str:
    """
    Переключить aiohttp на системный DNS-резолвер (ThreadedResolver).

    Реальный случай с Windows: aiohttp по умолчанию при установленном aiodns
    (ccxt.pro ставит его всегда) использует AsyncResolver — тот шлёт UDP-запросы
    НАПРЯМУЮ к DNS-серверам из настроек адаптера, минуя службу DNS-клиента
    Windows (dnscache). Антивирус, файрвол, правила VPN-приложений и
    «шифрованный DNS» (DoH) этот путь нередко блокируют, и тогда ВСЕ биржи
    мгновенно падают с:

        ClientConnectorDNSError: Cannot connect to host ...
        [Could not contact DNS servers]

    при этом браузер, urllib и socket.getaddrinfo работают нормально (шаг 4
    doctor зелёный, шаг 5 красный на всех биржах).

    ThreadedResolver выполняет тот же getaddrinfo в пуле потоков — системный
    путь, который работает всегда, когда работает сеть. Хостов у нас десяток,
    ОС кэширует ответы, поэтому разницы в производительности нет. Патч
    глобальный на процесс: TCPConnector берёт DefaultResolver из модуля
    aiohttp.connector в момент создания, так что он покрывает и REST, и
    WebSocket ccxt (WS использует ту же aiohttp-сессию биржи).

    DNS_RESOLVER=aiodns в .env возвращает дефолтное поведение aiohttp.
    """
    global _dns_resolver_logged
    mode = (os.getenv("DNS_RESOLVER", "") or "threaded").strip().lower()
    if mode in ("aiodns", "async", "default"):
        return "aiodns"
    try:
        import aiohttp.connector
        import aiohttp.resolver
    except Exception:
        return "threaded"
    if aiohttp.connector.DefaultResolver is not aiohttp.resolver.ThreadedResolver:
        aiohttp.connector.DefaultResolver = aiohttp.resolver.ThreadedResolver
        if not _dns_resolver_logged:
            log.info("aiohttp: DNS-резолвер переключён на системный (ThreadedResolver)")
    _dns_resolver_logged = True
    return "threaded"


# --------------------------------------------------------------------------
# Совместимость со старыми ccxt (<= 4.5.8x): чексумма стакана OKX
# --------------------------------------------------------------------------
_ccxt_compat_applied = False


def apply_ccxt_compat() -> bool:
    """
    None-безопасная `orderbook_checksum_message` для старых ccxt.

    Реальный случай (Windows, ccxt 4.5.52): в снапшоте канала books-l2-tbt
    у OKX элемент `data[0]` не содержит `instId`, поэтому внутри
    `handle_order_book_message` symbol=None. При любом расхождении чексуммы
    ccxt 4.5.52 строит сообщение `symbol + '  = False'` и падает с
    `TypeError: unsupported operand type(s) for +: 'NoneType' and 'str'`
    прямо в колбэке asyncio. Последствия: исключение теряется, future
    нашего `watch_order_book` не резолвится и не реджектится — поток
    стакана висит, а консоль спамится «Exception in callback».

    Патч делает форматирование сообщения None-безопасным: тогда вместо
    краха штатно строится ChecksumError, ccxt реджектит future, а наш
    _book_stream переподписывается и получает свежий снапшот (ресинк).
    В ccxt 4.5.85+ проверка чексуммы у OKX удалена целиком — там патч
    просто не задействуется. Идемпотентен, глобален на процесс
    (ccxt.pro наследуется от ccxt.base.exchange.Exchange).
    """
    global _ccxt_compat_applied
    if _ccxt_compat_applied:
        return False
    base = getattr(ccxt, "Exchange", None)
    if base is None or not hasattr(base, "orderbook_checksum_message"):
        return False

    def _none_safe_message(self, symbol):
        return (symbol if symbol is not None else "?") + "  = False"

    _none_safe_message._none_safe = True
    base.orderbook_checksum_message = _none_safe_message
    _ccxt_compat_applied = True
    log.info("ccxt: orderbook_checksum_message сделан None-безопасным (compat-патч)")
    return True


# явное переопределение из настроек (PROXY_URL), имеет приоритет над окружением
SETTINGS_PROXY_OVERRIDE: str = ""


class ExchangeCollector:
    def __init__(self, cfg: ExchangeConfig, settings: Settings) -> None:
        self.cfg = cfg
        self.settings = settings
        cls = getattr(ccxtpro, cfg.id)
        opts = {
            "enableRateLimit": True,
            "timeout": settings.request_timeout,
            "options": dict(cfg.options),
        }
        if cfg.market == "swap":
            opts["options"]["defaultType"] = "swap"
        # ограничиваем кэш сделок ccxt: иначе на каждой бирже копится по 1000
        # сделок на символ и память растёт на сотни мегабайт
        opts["options"].setdefault("tradesLimit", cfg.trades_limit)
        # Системный DNS-резолвер вместо aiodns: на Windows прямой UDP к
        # DNS-серверу часто блокируют (см. apply_dns_resolver). Патч глобальный
        # и идемпотентный, применяется до создания сессий aiohttp.
        apply_dns_resolver()
        apply_ccxt_compat()
        if cfg.id == "okx":
            # ccxt < 4.5.85 на ложных срабатываниях чексуммы стакана OKX
            # ронял TypeError в колбэке asyncio и вешал поток (см.
            # apply_ccxt_compat). Upstream в 4.5.85 удалил проверку вовсе —
            # отключаем её опцией: в новых версиях опцию никто не читает,
            # в старых она убирает аварийную ветку целиком.
            opts["options"].setdefault("watchOrderBook", {})["checksum"] = False
        apply_proxy(opts)
        self.ex = cls(opts)   # ccxt.pro умеет и WebSocket, и обычный REST

        self.symbols: list[str] = []          # полный отфильтрованный список биржи
        self.hot: list[str] = []              # активный стрим
        self.tasks: set[asyncio.Task] = set()
        self._stop = asyncio.Event()
        self._book_tasks: dict[str, asyncio.Task] = {}
        self._trade_tasks: dict[str, asyncio.Task] = {}
        self._ticker_tasks: dict[str, asyncio.Task] = {}
        self._id_map: dict[str, str] = {}
        self._sem_ohlcv = asyncio.Semaphore(settings.ohlcv_concurrency)
        # Отбору по волатильности нужны свечи сразу на весь пул кандидатов
        # (до 240 штук), и первый пересчёт с общим семафором (6) занимал 9.3 c -
        # UI всё это время держал POST /api/focus открытым. Отдельный семафор
        # шире: klines-эндпоинты бирж это переносят спокойно, а время первого
        # отбора падает в разы.
        self._sem_focus = asyncio.Semaphore(FOCUS_OHLCV_CONCURRENCY)
        self._sem_oi = asyncio.Semaphore(4)   # троттлинг точечных OI/funding-запросов
        self._candles_cache: dict[tuple, tuple[float, list]] = {}
        self._book_banned: set[str] = set()   # символы, по которым биржа стабильно отказывает
        self._ban_ts: float = time.time()
        self._book_limit_suspect: bool = False
        self._t0 = time.time()
        # --- фокус-режим ---
        self._focus_syms: Optional[list[str]] = None   # жёсткий список стрима
        self._focus_pool: Optional[list[str]] = None   # пул для подкачки свечей
        self._focus_wake = asyncio.Event()             # «список изменился, ротация»
        self._paused = False                           # биржа не в фокусе → спим

    # ------------------------------------------------------------------
    async def run(self) -> None:
        """
        Запуск коллектора биржи.

        Если рынки не загрузились, процесс НЕ останавливается: переходим в
        режим восстановления и периодически повторяем попытку. Транзиентный
        сбой DNS или кратковременная недоступность биржи не должны требовать
        ручного перезапуска скринера.
        """
        if not await self._load_markets():
            await self._revive_loop()
            return

        await self._after_markets_loaded()

    async def _load_markets(self) -> bool:
        """
        Загрузка метаданных рынков.

        ccxt по умолчанию тянет ВСЕ типы рынков биржи: у Gate это 7166 объектов
        (хотя свопов только 1025), у OKX — 4389, у Binance Spot — 4670. Только
        метаданные рынков на 8 биржах съедают ~380 МБ, и это главный потребитель
        памяти в приложении (история цен на 6000 символов — всего ~70 МБ).

        Ограничение `options.fetchMarkets` резко это режет (OKX: 4389 → 500,
        Bybit: 3667 → ~1400, Gate spot: 6827 → ~2200), но реализовано у бирж
        непоследовательно: канонический формат — словарь {"types": [...]},
        а имена типов перпетуалов различаются (Binance-семейство/Bybit —
        'linear'/'inverse', OKX/Gate/Hyperliquid — 'swap'); см.
        restrict_fetch_markets(). Голый список ["swap"] hyperliquid в ccxt
        4.5.52 вообще ронял с TypeError (BUGFIXES #47).
        Поэтому пробуем с ограничением и откатываемся к полной загрузке при
        ЛЮБОЙ несетевой ошибке и если рынков нужного типа не оказалось.
        Молча остаться с пустым списком нельзя.
        """
        want = self.cfg.market
        # Значение по умолчанию у каждой биржи своё (у Hyperliquid —
        # {"types": ["spot","swap","hip3"]}). Удалять ключ в откате нельзя:
        # ccxt останется без ориентира и вернёт 0 рынков. Только сохраняем
        # и восстанавливаем исходное.
        sentinel = object()
        original = self.ex.options.get("fetchMarkets", sentinel)

        async def try_load(restrict: bool) -> int:
            if restrict:
                self.ex.options["fetchMarkets"] = restrict_fetch_markets(self.cfg.id, want)
            elif original is sentinel:
                self.ex.options.pop("fetchMarkets", None)
            else:
                self.ex.options["fetchMarkets"] = original
            await self.ex.load_markets(reload=True)
            key = "swap" if want == "swap" else "spot"
            return sum(1 for m in self.ex.markets.values() if m.get(key))

        option_rejected = False
        for restrict in (True, False):
            try:
                got = await self._try_load_with_retries(try_load, restrict)
            except Exception as e:  # noqa: BLE001
                msg = describe_error(e)
                # Любая НЕСЕТЕВАЯ ошибка ограниченной загрузки — повод
                # откатиться к полной: биржа отвергла опцию (ExchangeError),
                # ccxt споткнулся о её формат (TypeError у hyperliquid в
                # 4.5.52) и т.п. Ограничение — лишь оптимизация памяти,
                # терять из-за него биржу нельзя. При сетевой ошибке второй
                # запрос — просто потерянное время и вдвое более запутанный
                # лог: причина не в опции, а в доступности API.
                if restrict and not is_network_error(e):
                    option_rejected = True
                    log.info("[%s] ограничение fetchMarkets не сработало (%s) — "
                             "загружаю все рынки", self.cfg.label, msg[:150])
                    continue
                level = log.warning if is_network_error(e) else log.error
                level("[%s] load_markets не удался: %s", self.cfg.label, msg)
                STORE.set_status(self.cfg.label, state="error", error=msg[:300])
                STORE.bump("errors")
                return False
            if got > 0:
                if restrict:
                    log.info("[%s] рынков %s: %d (всего метаданных %d)",
                             self.cfg.label, want, got, len(self.ex.markets))
                elif option_rejected:
                    # ограничение отвергла биржа/ccxt — это нормально, просто
                    # памяти уйдёт больше (ccxt тянет метаданные всех рынков)
                    log.info("[%s] fetchMarkets=[%s] отклонено — загружены все рынки, "
                             "нужного типа %d (метаданных %d)",
                             self.cfg.label, want, got, len(self.ex.markets))
                else:
                    log.info("[%s] fetchMarkets=[%s] не дал рынков этого типа — "
                             "загружены все (%d), нужного типа %d",
                             self.cfg.label, want, len(self.ex.markets), got)
                return True
        log.warning("[%s] рынков типа %s не найдено", self.cfg.label, want)
        STORE.set_status(self.cfg.label, state="error", error=f"нет рынков типа {want}")
        return False

    async def _try_load_with_retries(self, try_load, restrict: bool) -> int:
        """
        Повторяет load_markets с нарастающей задержкой.

        Зачем: у Gate загрузка рынков занимает ~19 c, у Hyperliquid ~16 c,
        а дефолтный таймаут ccxt — 10 c на запрос. На нестабильном канале
        отдельный запрос периодически не укладывается, и без ретраев биржа
        оставалась неподключённой до перезапуска процесса.

        Сетевые ошибки повторяем; ошибки конфигурации (неверная опция,
        неподдерживаемый рынок) — нет, они от повтора не пройдут.
        """
        attempts = max(1, self.settings.load_retries)
        delay = 2.0
        last: Optional[BaseException] = None
        for attempt in range(1, attempts + 1):
            try:
                return await try_load(restrict)
            except asyncio.CancelledError:
                raise
            except Exception as e:  # noqa: BLE001
                last = e
                if not is_network_error(e):
                    raise                      # не сеть — повторять бессмысленно
                if attempt < attempts:
                    log.info("[%s] load_markets: попытка %d/%d не удалась (%s), "
                             "повтор через %.0f c",
                             self.cfg.label, attempt, attempts,
                             describe_error(e)[:110], delay)
                    await asyncio.sleep(delay)
                    delay = min(delay * 2, 20.0)
        if last:
            raise last
        return 0

    async def _revive_loop(self) -> None:
        """Периодически повторяет подключение биржи, отвалившейся на старте."""
        interval = max(15.0, self.settings.revive_interval)
        log.warning("[%s] биржа не подключилась — буду повторять каждые %.0f c "
                    "(остальные биржи работают)", self.cfg.label, interval)
        STORE.set_status(self.cfg.label, state="retrying")
        while not self._stop.is_set():
            try:
                await asyncio.wait_for(self._stop.wait(), timeout=interval)
                return                          # поступил сигнал остановки
            except asyncio.TimeoutError:
                pass
            if await self._load_markets():
                log.info("[%s] подключение восстановлено", self.cfg.label)
                await self._after_markets_loaded()
                return
        return

    async def _after_markets_loaded(self) -> None:
        """Запуск рабочих циклов — вынесено, чтобы его мог вызвать и revive."""
        self.symbols = self._select_symbols()
        STORE.set_status(self.cfg.label, state="online", symbols=len(self.symbols),
                         total=len(self.symbols))
        log.info("[%s] %d symbols (%s)", self.cfg.label, len(self.symbols), self.cfg.market)

        self._spawn(self._ticker_loop(), name="tickers")
        self._spawn(self._rotate_loop(), name="rotate")
        if self.settings.fetch_ohlcv:
            self._spawn(self._ohlcv_loop(), name="ohlcv")
        self._spawn(self._funding_loop(), name="funding")
        # снапшот пишем только в live-режиме: иначе replay перезаписал бы
        # боевой снимок рынка своей синтетикой
        if self.settings.mode == "live":
            self._spawn(self._snapshot_dump_loop(), name="snapshot")

        await self._stop.wait()
        for t in list(self.tasks):
            t.cancel()
        await asyncio.gather(*self.tasks, return_exceptions=True)
        with contextlib.suppress(Exception):
            await self.ex.close()

    def _spawn(self, coro, name: str) -> asyncio.Task:
        t = asyncio.create_task(coro, name=f"{self.cfg.id}:{name}")
        self.tasks.add(t)
        t.add_done_callback(self.tasks.discard)
        return t

    async def stop(self) -> None:
        self._stop.set()

    # ------------------------------------------------------------------
    # Фокус-режим: внешний жёсткий список стрима
    # ------------------------------------------------------------------
    def set_focus(self, symbols: Optional[list[str]], pool: Optional[list[str]] = None) -> bool:
        """
        Переводит коллектор в фокус-режим (список) или возвращает в обычный (None).

        Возвращает True, если состав изменился и подписки надо пересобрать.
        Список копируется: владелец (FocusManager) свой может менять на месте.
        """
        new = list(symbols) if symbols else None
        changed = (new or []) != (self._focus_syms or [])
        self._focus_syms = new
        self._focus_pool = list(pool) if pool else (list(new) if new else None)
        if changed:
            self._focus_wake.set()
        return changed

    def set_ohlcv_pool(self, pool: Optional[list[str]]) -> None:
        """Кандидаты, которым нужны свечи (уровень 2 отбора по волатильности)."""
        self._focus_pool = list(pool) if pool else None

    def pause(self) -> bool:
        """
        Биржа НЕ в фокусе: гасим тяжёлые потоки, опрос тикеров замедляем.

        Тикеры остаются — таблица скринера и карта рынка живут именно на них,
        а стоят один REST-запрос на биржу раз в PAUSED_TICKER_REFRESH секунд.
        """
        if self._paused:
            return False
        self._paused = True
        self._focus_wake.set()
        log.info("[%s] пауза: биржа вне фокуса, потоки закрыты", self.cfg.label)
        return True

    def resume(self) -> bool:
        if not self._paused:
            return False
        self._paused = False
        self._focus_wake.set()
        log.info("[%s] возобновление стримов", self.cfg.label)
        return True

    @property
    def focus_mode(self) -> bool:
        return bool(self._focus_syms)

    @property
    def paused(self) -> bool:
        return self._paused

    def _close_streams(self) -> None:
        """
        Закрыть все WS-потоки; отписки на бирже — фоново.

        Раньше каждый un_watch_* ожидался здесь последовательно, и пауза биржи
        со 150 подписками (~130 отписок по ~0.3 c) блокировала ротацию на
        ~40 секунд: сигнал resume() приходил, пока цикл был занят, и биржа
        возвращалась к работе только через HOT_ROTATE. Живой замер: через 15 c
        после выключения фокуса Binance всё ещё стримил 50 монет вместо 150.
        """
        books = sorted(self._book_tasks)
        trades = sorted(self._trade_tasks)
        tickers = sorted(self._ticker_tasks)
        for d in (self._book_tasks, self._trade_tasks, self._ticker_tasks):
            for t in list(d.values()):
                t.cancel()
            d.clear()
        # un_watch_ticker для символов без ленты сделок тоже нужен
        self._detach_cleanup(books, sorted(set(trades) | set(tickers)))

    async def ensure_ohlcv(self, symbols: list[str], limit: int = 400) -> int:
        """
        Принудительно добить 1m-свечи списку символов (вне цикла _ohlcv_loop).

        Нужно отбору по волатильности: кандидаты ещё не входят в горячий набор,
        их st.ohlcv пуст, NATR=None — и фильтр молча отбросил бы их все.
        Возвращает число символов, которым свечи реально обновили.
        """
        ok = 0

        async def one(sym: str) -> bool:
            async with self._sem_focus:
                try:
                    candles = await self.ex.fetch_ohlcv(sym, "1m", limit=limit)
                    STORE.bump("rest_calls")
                    if candles:
                        self._state(sym).apply_ohlcv(candles)
                        return True
                except (ccxt.RateLimitExceeded, ccxt.DDoSProtection):
                    await asyncio.sleep(1.5)
                except Exception as e:  # noqa: BLE001
                    STORE.bump("errors")
                    log.debug("[%s] focus ohlcv %s: %s", self.cfg.label, sym, str(e)[:120])
                return False

        res = await asyncio.gather(*[one(s) for s in symbols], return_exceptions=True)
        ok = sum(1 for r in res if r is True)
        return ok

    # ------------------------------------------------------------------
    # Отбор инструментов
    # ------------------------------------------------------------------
    def _select_symbols(self) -> list[str]:
        quotes = set(self.settings.quote_assets)
        out: list[str] = []
        for sym, m in self.ex.markets.items():
            if not m.get("active", True):
                continue
            if self.cfg.market == "swap" and not m.get("swap"):
                continue
            if self.cfg.market == "spot" and not m.get("spot"):
                continue
            if m.get("quote") not in quotes:
                continue
            out.append(sym)
        return out

    async def _refresh_top(self) -> list[str]:
        """top_n инструментов по 24h объёму в.quote."""
        try:
            # None → биржа отдаёт все тикеры одним запросом (~0.2 c на Binance);
            # список из 700+ символов заставлял ccxt работать заметно дольше
            tickers = await self.ex.fetch_tickers(None)
            STORE.bump("rest_calls")
        except Exception as e:  # noqa: BLE001
            log.warning("[%s] fetch_tickers: %s", self.cfg.label, str(e)[:160])
            STORE.bump("errors")
            return self.hot

        allowed = set(self.symbols)
        rows = []
        for sym, t in tickers.items():
            if sym not in self.ex.markets or sym not in allowed:
                continue
            st = self._state(sym)
            st.apply_ticker(t)
            STORE.bump("ticker_updates")
            qv = t.get("quoteVolume") or 0.0
            rows.append((qv, sym))
        rows.sort(reverse=True)
        top = [s for _, s in rows[: self.cfg.top_n]]

        # референсные цены BTC/ETH — чтобы объёмы в BTC-парах приводились к USD
        btc = _find_last(tickers, "BTC")
        eth = _find_last(tickers, "ETH")
        if btc or eth:
            set_reference_prices(btc, eth)

        return top

    def _state(self, symbol: str):
        m = self.ex.market(symbol)
        st = STORE.get_or_create(self.cfg.id, self.cfg.label, self.cfg.market, symbol,
                                 m.get("base") or symbol.split("/")[0], m.get("quote") or "")
        # без этого инверсные контракты считаются в неверных единицах
        st.set_contract(bool(m.get("inverse")), m.get("contractSize"))
        st.ohlcv_vol_in_contracts = self.cfg.ohlcv_vol_in_contracts
        st.dex = self.cfg.dex
        return st

    # ------------------------------------------------------------------
    # Циклы
    # ------------------------------------------------------------------
    async def _ticker_loop(self) -> None:
        while not self._stop.is_set():
            t0 = time.time()
            await self._refresh_top()
            STORE.set_status(self.cfg.label, latency_ms=int((time.time() - t0) * 1000))
            base = self.cfg.ticker_refresh or self.settings.ticker_refresh
            # биржа вне фокуса: тикеры всё равно нужны (таблица/карта), но
            # долбить биржу раз в 20 секунд ради невидимых данных незачем
            await asyncio.sleep(max(base, PAUSED_TICKER_REFRESH) if self._paused else base)
            if self._stop.is_set():
                break

    async def _rotate_loop(self) -> None:
        """
        Пересобирает горячий набор и (пере)подключает WS-потоки.

        Монета «в игре» (вырос объём) → попадает в топ → на неё заводятся
        стримы. Протухла → выпадает из топа → стримы гасятся И снимается
        подписка на бирже через un_watch_*, иначе список подписок растёт
        бесконечно и соединение деградирует.

        В фокус-режиме список приходит снаружи (set_focus), а ротация
        просыпается по _focus_wake — поэтому первые графики появляются
        через FOCUS_ROTATE_DELAY, а не через HOT_ROTATE.
        """
        await asyncio.sleep(ROTATE_START_DELAY)
        while not self._stop.is_set():
            try:
                if self._paused:
                    # биржа вне фокуса: подписок не держим вовсе
                    if self._book_tasks or self._trade_tasks or self._ticker_tasks:
                        self._close_streams()
                    STORE.set_status(self.cfg.label, state="paused",
                                     symbols=len(self.symbols), books=0, trades=0,
                                     hot=0, banned=len(self._book_banned))
                    self._focus_wake.clear()
                    await self._sleep_rotate(HOT_ROTATE)
                    continue

                if self._focus_syms is not None:
                    # фокус-режим: список пришёл снаружи (отбор по фильтру),
                    # собственный расчёт топа по объёму не нужен.
                    # Флаг сбрасываем ДО чтения списка: всё, что придёт после,
                    # гарантированно разбудит ротацию ещё раз.
                    self._focus_wake.clear()
                    top = list(self._focus_syms)
                else:
                    top = await self._refresh_top()
                    if not top:
                        top = self.hot
                self.hot = top
                book_n = min(self.cfg.books, len(top)) if self._focus_syms else self.cfg.books
                trade_n = min(TRADES_STREAM_N, len(top)) if self._focus_syms else TRADES_STREAM_N
                want_books = set(top[:book_n])
                want_trades = set(top[:trade_n])

                # --- заводим новые ---
                for s in want_books - set(self._book_tasks) - self._book_banned:
                    self._book_tasks[s] = self._spawn(self._book_stream(s), name=f"book:{s}")
                for s in want_trades - set(self._trade_tasks):
                    self._trade_tasks[s] = self._spawn(self._trade_stream(s), name=f"trades:{s}")
                    self._ticker_tasks[s] = self._spawn(self._ticker_stream(s), name=f"tk:{s}")

                # --- гасим протухшие ---
                drop_books = sorted(set(self._book_tasks) - want_books)
                drop_trades = sorted(set(self._trade_tasks) - want_trades)
                for s in drop_books:
                    self._book_tasks.pop(s).cancel()
                for s in drop_trades:
                    self._trade_tasks.pop(s).cancel()
                    if s in self._ticker_tasks:
                        self._ticker_tasks.pop(s).cancel()
                if drop_books or drop_trades:
                    self._detach_cleanup(drop_books, drop_trades)

                # Массовый бан почти всегда означает НЕ плохие символы, а
                # невалидную глубину стакана: Gate на limit=200 отвечает
                # BadRequest по всем подпискам, и без этой проверки биржа
                # молча осталась бы вообще без плотностей.
                wanted = max(self.cfg.books, 1)
                if len(self._book_banned) >= max(3, int(wanted * 0.5)):
                    log.error("[%s] забанено %d из %d стаканов — похоже на невалидный "
                              "book_limit=%d (допустимые значения см. VALID_BOOK_LIMITS). "
                              "Снимаем бан и продолжаем с увеличенным backoff.",
                              self.cfg.label, len(self._book_banned), wanted, self.cfg.book_limit)
                    self._book_banned.clear()
                    self._book_limit_suspect = True
                # амнистия: раз в BAN_TTL даём забаненным символам ещё один шанс —
                # делистинги и сбои биржи проходят, а навсегда выключенный стакан
                # сам не восстановится
                elif self._book_banned and time.time() - self._ban_ts > BAN_TTL:
                    log.info("[%s] амнистия %d забаненных стаканов",
                             self.cfg.label, len(self._book_banned))
                    self._book_banned.clear()
                    self._ban_ts = time.time()

                STORE.set_status(self.cfg.label, state="online", symbols=len(self.symbols),
                                 books=len(self._book_tasks), trades=len(self._trade_tasks),
                                 hot=len(self.hot), banned=len(self._book_banned),
                                 focus=self.focus_mode,
                                 book_limit_suspect=self._book_limit_suspect)
            except Exception as e:  # noqa: BLE001
                log.warning("[%s] rotate: %s", self.cfg.label, str(e)[:160])
                STORE.bump("errors")
            if self._stopped():
                break
            await self._sleep_rotate(HOT_ROTATE)

    def _stopped(self) -> bool:
        """Стоп ИЛИ пауза: оба случая прерывают ожидание ротации."""
        return self._stop.is_set() or self._paused

    async def _sleep_rotate(self, delay: float) -> None:
        """
        Сон ротации с ранним пробуждением по set_focus()/pause()/resume().

        Флаг намеренно НЕ сбрасывается здесь. Раньше он чистился перед
        ожиданием, и сигнал, пришедший ПОКА ротация разбиралась с подписками
        (а это десятки секунд на массовых отписках), терялся: следующий
        пересчёт случался только через HOT_ROTATE. Живой замер показывал
        hot=50 ещё 50 секунд после выключения фокус-режима. Теперь флаг
        сбрасывается в момент потребления списка (см. _rotate_loop).
        """
        try:
            await asyncio.wait_for(self._focus_wake.wait(), timeout=delay)
            # список изменился — пересобираем подписки почти сразу, но не
            # чаще FOCUS_ROTATE_DELAY, чтобы серия обновлений не долбила биржу
            await asyncio.sleep(FOCUS_ROTATE_DELAY)
        except asyncio.TimeoutError:
            pass

    def _detach_cleanup(self, books: list[str], trades: list[str]) -> None:
        """
        Снятие подписок — фоново и параллельно.

        Последовательные `await un_watch_*` внутри ротации стоили 56 секунд на
        переходе 150 → 50 подписок (замер на живом Binance: ~170 отписок по
        ~0.3 c). Всё это время ротация не могла применить новый список, то есть
        фокус-режим «залипал» на старом наборе. Отписки не блокируют rotaciju:
        задачи на бирже уже отменены, остальное - вежливость к соединению.
        """
        t = asyncio.create_task(self._unwatch_many(books, trades),
                                name=f"{self.cfg.id}:unwatch")
        self.tasks.add(t)
        t.add_done_callback(self.tasks.discard)

    async def _unwatch_many(self, books: list[str], trades: list[str]) -> None:
        coros = [self._unwatch("order_book", s) for s in books]
        for s in trades:
            coros.append(self._unwatch("trades", s))
            coros.append(self._unwatch("ticker", s))
        if coros:
            await asyncio.gather(*coros, return_exceptions=True)

    async def _unwatch(self, kind: str, symbol: str) -> None:
        """Снимаем подписку на стороне биржи (best effort)."""
        method = {"order_book": "un_watch_order_book", "trades": "un_watch_trades",
                  "ticker": "un_watch_ticker"}.get(kind)
        if not method or not hasattr(self.ex, method):
            return
        try:
            await getattr(self.ex, method)(symbol)
        except Exception:  # noqa: BLE001
            pass

    async def _ticker_stream(self, symbol: str) -> None:
        while not self._stop.is_set():
            try:
                q = await self.ex.watch_ticker(symbol)
                self._state(symbol).apply_quote(q)
                STORE.bump("ws_messages")
            except asyncio.CancelledError:
                return
            except (ccxt.BadSymbol, ccxtpro.BadSymbol):
                self._ticker_tasks.pop(symbol, None)
                return
            except (ccxt.NetworkError, ccxtpro.NetworkError):
                await asyncio.sleep(1)
            except Exception as e:  # noqa: BLE001
                STORE.bump("errors")
                log.debug("[%s] ticker %s: %s: %s", self.cfg.label, symbol,
                          type(e).__name__, str(e)[:140])
                await asyncio.sleep(2)

    async def _trade_stream(self, symbol: str) -> None:
        while not self._stop.is_set():
            try:
                tr = await self.ex.watch_trades(symbol)
                st = self._state(symbol)
                for t in tr:
                    st.apply_trade(t)
                    STORE.bump("trades")
                STORE.bump("ws_messages")
            except asyncio.CancelledError:
                return
            except (ccxt.BadSymbol, ccxtpro.BadSymbol):
                self._trade_tasks.pop(symbol, None)
                return
            except (ccxt.NetworkError, ccxtpro.NetworkError):
                await asyncio.sleep(1)
            except Exception as e:  # noqa: BLE001
                STORE.bump("errors")
                log.debug("[%s] trades %s: %s: %s", self.cfg.label, symbol,
                          type(e).__name__, str(e)[:140])
                await asyncio.sleep(2)

    async def _book_stream(self, symbol: str) -> None:
        fails = 0
        first_fail = 0.0
        backoff = 2.0
        while not self._stop.is_set():
            try:
                book = await self.ex.watch_order_book(symbol, limit=self.cfg.book_limit)
                self._state(symbol).apply_book(
                    book,
                    big_usd=self.settings.big_density_usd,
                    huge_usd=self.settings.huge_density_usd,
                    depth=self.cfg.book_limit,
                )
                STORE.bump("book_updates")
                STORE.bump("ws_messages")
                fails = 0
                backoff = 2.0
            except asyncio.CancelledError:
                return
            except (ccxt.BadSymbol, ccxtpro.BadSymbol):
                self._book_tasks.pop(symbol, None)
                return
            except (ccxt.NetworkError, ccxtpro.NetworkError):
                await asyncio.sleep(1)          # транзиентная — счётчик не трогаем
            except Exception as e:  # noqa: BLE001
                STORE.bump("errors")
                now = time.time()
                fails += 1
                if not first_fail:
                    first_fail = now
                elif now - first_fail > FAIL_WINDOW:
                    # отказы идут вразнобой, а не одной пачкой — сбрасываем счёт,
                    # иначе транзитентные сбои постепенно забанят весь стакан
                    fails, first_fail, backoff = 1, now, 2.0

                if fails >= MAX_STREAM_FAILS:
                    # Ключевое различие: биржа стабильно отказывает ПО ЭТОМУ
                    # символу (у Gate так ведёт себя 龙虾/USDT:USDT) — или
                    # оборвалось соединение, и отказали сразу все подписки.
                    # Во втором случае банить нельзя: после обрыва все 12
                    # стаканов Gate отказали в пределах 100 мс с одним conn_id,
                    # и выключатель навсегда выключил бы стакан биржи.
                    if now - first_fail < CORRELATED_FAIL_WINDOW:
                        log.info("[%s] book %s: отказ в общей пачке (%d за %.1f c) — "
                                 "похоже на обрыв соединения, продолжаем с backoff",
                                 self.cfg.label, symbol, fails, now - first_fail)
                        fails, first_fail = 0, 0.0
                    else:
                        log.warning("[%s] book %s: %d отказов за %.0f c, поток остановлен (%s)",
                                    self.cfg.label, symbol, fails, now - first_fail, str(e)[:90])
                        if self._book_limit_suspect:
                            # не банить: проблема в конфигурации, а не в символе
                            fails, first_fail, backoff = 0, 0.0, 30.0
                        else:
                            self._book_tasks.pop(symbol, None)
                            self._book_banned.add(symbol)
                            return
                else:
                    log.debug("[%s] book %s: %s: %s", self.cfg.label, symbol,
                              type(e).__name__, str(e)[:140])
                await asyncio.sleep(backoff)
                backoff = min(backoff * 1.7, 30.0)   # не долбим биржу в tight-цикле

    # ------------------------------------------------------------------
    async def _ohlcv_loop(self) -> None:
        """Подкачка 1m-свечей для горячего набора → NATR и мульти-ТФ."""
        await asyncio.sleep(8)
        while not self._stop.is_set():
            if self._focus_pool:
                # фокус-режим: свечи держим на пуле кандидатов (из них
                # пересчитывается отбор), а не на всём горячем наборе
                batch = self._focus_pool[: self.cfg.top_n]
            else:
                batch = self.hot[: self.cfg.top_n]
            if not self._paused:
                await asyncio.gather(*[self._fetch_ohlcv(s) for s in batch],
                                     return_exceptions=True)
            await asyncio.sleep(max(60.0, self.settings.ticker_refresh * 3))

    async def _fetch_ohlcv(self, symbol: str) -> None:
        async with self._sem_ohlcv:
            try:
                candles = await self.ex.fetch_ohlcv(symbol, "1m", limit=self.settings.ohlcv_limit)
                STORE.bump("rest_calls")
                if candles:
                    self._state(symbol).apply_ohlcv(candles)
            except (ccxt.RateLimitExceeded, ccxt.DDoSProtection):
                await asyncio.sleep(2)
            except Exception as e:  # noqa: BLE001
                STORE.bump("errors")
                log.debug("[%s] ohlcv %s: %s: %s", self.cfg.label, symbol,
                          type(e).__name__, str(e)[:140])

    # ------------------------------------------------------------------
    async def _funding_loop(self) -> None:
        """
        Funding + Open Interest.

        Приоритет источников:
          1. ccxt fetch_funding_rates() — bulk-вызов сразу по всем символам.
             Работает у Gate/Aster/Hyperliquid/Bybit/OKX, поэтому новую биржу
             не нужно прописывать вручную.
          2. Нативные bulk-эндпоинты — там, где ccxt bulk не даёт (Binance).
          3. Точечно по топ-N — для OI, bulk-эндпоинта нет почти ни у кого.
        """
        if self.cfg.market != "swap":
            return
        await asyncio.sleep(10)
        while not self._stop.is_set():
            try:
                self._apply_oi_funding(await self._funding_bulk())
                self._apply_oi_funding(await self._oi_bulk())
                self._apply_oi_funding(await self._oi_targeted())
            except Exception as e:  # noqa: BLE001
                log.debug("[%s] funding loop: %s", self.cfg.label, str(e)[:160])
                STORE.bump("errors")
            await asyncio.sleep(FUNDING_REFRESH)

    def _apply_oi_funding(self, data: list[tuple[str, Optional[float], Optional[float], Optional[float]]]) -> None:
        """data: (symbol, oi, oi_usd, funding) — None означает «метрика не получена»."""
        if not data:
            return
        applied = 0
        for symbol, oi, oi_usd, funding in data:
            if symbol not in self.ex.markets:
                continue
            st = self._state(symbol)
            if oi is not None:
                prev = st.open_interest
                st.open_interest = oi
                if prev:
                    st.oi_change_pct = (oi / prev - 1.0) * 100.0
            if oi_usd is not None:
                st.open_interest_usd = oi_usd
            if funding is not None:
                st.funding = funding
            st.touch()
            applied += 1
        if applied:
            STORE.bump("rest_calls")
            log.debug("[%s] OI/funding applied for %d symbols", self.cfg.label, applied)

    async def _funding_bulk(self) -> list[tuple[str, Optional[float], Optional[float], Optional[float]]]:
        # 1) универсальный путь через ccxt
        if self.ex.has.get("fetchFundingRates"):
            try:
                rates = await self.ex.fetch_funding_rates()
                STORE.bump("rest_calls")
                return [(sym, None, None, _f(r.get("fundingRate")))
                        for sym, r in rates.items() if r.get("fundingRate") is not None]
            except Exception as e:  # noqa: BLE001
                log.debug("[%s] fetch_funding_rates: %s", self.cfg.label, str(e)[:140])
                STORE.bump("errors")
        # 2) нативный bulk. Binance-совместимый premiumIndex отдают Binance и
        #    Aster (проверено: 923 и 767 контрактов, поле lastFundingRate).
        prem = PREMIUM_INDEX_URLS.get(self.cfg.id)
        if prem:
            loop = asyncio.get_running_loop()
            try:
                raw = await loop.run_in_executor(None, _get_json, prem)
                STORE.bump("rest_calls")
                out = []
                for r in raw:
                    sym = self._to_ccxt_symbol(r.get("symbol", ""))
                    if sym:
                        out.append((sym, None, None, _f(r.get("lastFundingRate"))))
                return out
            except Exception as e:  # noqa: BLE001
                log.debug("[%s] premiumIndex: %s", self.cfg.label, str(e)[:140])
                STORE.bump("errors")
        return []

    async def _oi_bulk(self) -> list[tuple[str, Optional[float], Optional[float], Optional[float]]]:
        """OI одним запросом на всю биржу — только там, где такой эндпоинт есть."""
        loop = asyncio.get_running_loop()
        eid = self.cfg.id
        out: list[tuple[str, Optional[float], Optional[float], Optional[float]]] = []
        try:
            if eid == "bybit":
                res = await loop.run_in_executor(
                    None, _get_json, "https://api.bybit.com/v5/market/tickers?category=linear")
                for r in (res.get("result") or {}).get("list") or []:
                    sym = self._to_ccxt_symbol(r.get("symbol", ""))
                    if sym:
                        out.append((sym, _f(r.get("openInterest")),
                                    _f(r.get("openInterestValue")), None))
            elif eid == "okx":
                res = await loop.run_in_executor(
                    None, _get_json, "https://www.okx.com/api/v5/public/open-interest?instType=SWAP")
                for r in res.get("data") or []:
                    sym = self._to_ccxt_symbol(r.get("instId", ""))
                    if sym:
                        out.append((sym, _f(r.get("oiCcy")), _f(r.get("oiUsd")), None))
            elif eid == "gate":
                # /contract_stats требует contract= и потому НЕ bulk (400 без него).
                # /contracts отдаёт все ~1024 контракта одним запросом и содержит
                # position_size — суммарный открытый интерес в контрактах.
                #
                # Важно: contract_stats.open_interest ровно вдвое больше
                # position_size · quanto_multiplier (Gate считает обе стороны),
                # поэтому берём position_size — это стандартная конвенция OI,
                # как у Binance/Bybit/OKX. Сверено: BTC 2.379B vs 4.756B (×2.000),
                # ETH 1.106B vs 2.229B (×2.000).
                res = await loop.run_in_executor(
                    None, _get_json, "https://api.gateio.ws/api/v4/futures/usdt/contracts")
                for r in res or []:
                    sym = self._to_ccxt_symbol(str(r.get("name", "")))
                    if not sym:
                        continue
                    pos = _f(r.get("position_size"))
                    mult = _f(r.get("quanto_multiplier"))
                    mark = _f(r.get("mark_price")) or _f(r.get("last_price"))
                    oi_base = pos * mult if (pos is not None and mult) else None
                    oi_usd = oi_base * mark if (oi_base is not None and mark) else None
                    out.append((sym, oi_base, oi_usd, None))
            elif eid == "mexc":
                # /contract/ticker без symbol отдаёт ВСЕ контракты: holdVol (OI),
                # fundingRate и amount24 одним запросом. ccxt для MEXC
                # fetchOpenInterest/fetchFundingRates не реализовал.
                res = await loop.run_in_executor(
                    None, _get_json, "https://contract.mexc.com/api/v1/contract/ticker")
                for r in res.get("data") or []:
                    sym = self._to_ccxt_symbol(str(r.get("symbol", "")))
                    if not sym:
                        continue
                    hold = _f(r.get("holdVol"))
                    mark = _f(r.get("fairPrice")) or _f(r.get("lastPrice"))
                    cs = self.ex.market(sym).get("contractSize") or 1.0
                    # holdVol в тех же единицах, что и volume24; соотношение
                    # volume24·contractSize·price ≈ amount24 сверено на BTC (±2.5%)
                    oi_base = hold * cs if hold is not None else None
                    oi_usd = oi_base * mark if (oi_base is not None and mark) else None
                    out.append((sym, oi_base, oi_usd, _f(r.get("fundingRate"))))
            if out:
                STORE.bump("rest_calls")
        except Exception as e:  # noqa: BLE001
            log.debug("[%s] oi bulk: %s", self.cfg.label, str(e)[:140])
            STORE.bump("errors")
        return out

    async def _oi_targeted(self) -> list[tuple[str, Optional[float], Optional[float], Optional[float]]]:
        """
        Точечный OI по горячему топу — для бирж без bulk-эндпоинта
        (Binance, MEXC, Aster, Hyperliquid).
        """
        if self._has_oi_bulk():
            return []
        native = NATIVE_OI_URL.get(self.cfg.id)
        if not native and not self.ex.has.get("fetchOpenInterest"):
            return []
        targets = self.hot[: self.cfg.oi_top_n]
        if not targets:
            return []

        loop = asyncio.get_running_loop()

        async def one(sym: str):
            async with self._sem_oi:
                try:
                    m = self.ex.market(sym)
                    st = STORE.get(f"{self.cfg.id}:{sym}")
                    px = st.last if st and st.last else None

                    # 1) нативный эндпоинт — для бирж, где ccxt не реализовал
                    #    fetchOpenInterest (Aster). Ответ в Binance-формате.
                    if native:
                        url = native + urllib.parse.quote(str(m["id"]))
                        r = await loop.run_in_executor(None, _get_json, url)
                        oi = _f(r.get("openInterest"))
                        if oi is None and isinstance(r.get("data"), dict):
                            oi = _f(r["data"].get("openInterest"))
                        oi_usd = oi * px if (oi is not None and px) else None
                        return (sym, oi, oi_usd, None)

                    # 2) OKX: bulk OI уже получен, добираем только funding
                    if self.cfg.id == "okx":
                        url = ("https://www.okx.com/api/v5/public/funding-rate?instId="
                               + urllib.parse.quote(str(m["id"])))
                        r = await loop.run_in_executor(None, _get_json, url)
                        d = (r.get("data") or [{}])[0]
                        return (sym, None, None, _f(d.get("fundingRate")))

                    # 3) универсальный путь через ccxt (Binance, Hyperliquid, ...)
                    oi = await self.ex.fetch_open_interest(sym)
                    amt = _f(oi.get("openInterestAmount") if isinstance(oi, dict) else oi)
                    val = _f(oi.get("openInterestValue")) if isinstance(oi, dict) else None
                    if val is None and amt is not None and px:
                        val = amt * (1.0 if st and st.inverse else (m.get("contractSize") or 1.0)) * px
                    return (sym, amt, val, None)
                except Exception as e:  # noqa: BLE001
                    STORE.bump("errors")
                    log.debug("[%s] oi targeted %s: %s: %s", self.cfg.label, sym,
                              type(e).__name__, str(e)[:120])
                return None

        res = await asyncio.gather(*[one(s) for s in targets], return_exceptions=True)
        out = [r for r in res if isinstance(r, tuple)]
        if out:
            STORE.bump("rest_calls")
        return out

    def _has_oi_bulk(self) -> bool:
        return self.cfg.id in ("bybit", "okx", "gate", "mexc")

    # ------------------------------------------------------------------
    # Свечи для графиков (по требованию, с кэшем)
    # ------------------------------------------------------------------
    async def fetch_candles(self, symbol: str, tf: str, limit: int) -> list:
        """
        OHLCV для карточки инструмента. Кэш на CANDLES_TTL секунд: график
        открывают часто, а дёргать биржу на каждый запрос — путь к 429.
        """
        cache_key = (symbol, tf, limit)
        hit = self._candles_cache.get(cache_key)
        now = time.time()
        if hit and now - hit[0] < CANDLES_TTL:
            return hit[1]
        if symbol not in self.ex.markets:
            return []
        try:
            candles = await self.ex.fetch_ohlcv(symbol, tf, limit=limit)
            STORE.bump("rest_calls")
        except Exception as e:  # noqa: BLE001
            log.debug("[%s] fetch_candles %s %s: %s", self.cfg.label, symbol, tf, str(e)[:140])
            STORE.bump("errors")
            return hit[1] if hit else []
        self._candles_cache[cache_key] = (now, candles)
        return candles


    def _to_ccxt_symbol(self, raw: str) -> Optional[str]:
        """
        Биржевой идентификатор (BTCUSDT / BTC_USDT / BTC-USDT-SWAP) → ccxt-символ.

        Все ветки отфильтрованы по типу рынка: у Gate/Bybit/Aster один и тот же
        id есть и у спота, и у свопа, поэтому наивный поиск «первого в markets»
        возвращал BTC/USDT (спот) вместо BTC/USDT:USDT — и OI/funding уходили
        не в тот инструмент.
        """
        if not raw:
            return None
        want = self.cfg.market
        cands = [raw, raw.replace("_", "/"), raw.replace("-", "/")]
        # сначала — точное совпадение по нужному типу рынка
        for c in cands:
            m = self.ex.markets.get(c)
            if m and m.get("type") == want:
                return c
        # затем — карта id (собрана с приоритетом своего типа рынка)
        if not self._id_map:
            self._build_id_map()
        hit = self._id_map.get(raw) or self._id_map.get(raw.upper())
        if hit:
            return hit
        # крайний случай: любой существующий символ (лучше чужой тип, чем ничего)
        for c in cands:
            if c in self.ex.markets:
                return c
        return None

    def _build_id_map(self) -> None:
        """
        Карта биржевого id → ccxt-символ.

        Один и тот же id бывает у спота и у свопа: у Gate таких коллизий 526,
        у Bybit 292, у Aster 40 («BTC_USDT» → и «BTC/USDT», и «BTC/USDT:USDT»).
        При наивной сборке побеждает последний записанный рынок, и OI/funding
        уезжают в спотовый инструмент вместо фьючерсного. Поэтому рынки
        чужого типа пишем первыми — свой тип перезапишет их.
        """
        items = list(self.ex.markets.items())
        ours = [(s_, m) for s_, m in items if m.get("type") == self.cfg.market]
        other = [(s_, m) for s_, m in items if m.get("type") != self.cfg.market]
        for sym, m in other + ours:
            self._id_map[str(m.get("id") or "")] = sym
            self._id_map[sym.replace("/", "")] = sym

    # ------------------------------------------------------------------
    async def _snapshot_dump_loop(self) -> None:
        """Периодически пишет снапшот на диск — из него потом работает replay-режим."""
        path = self.settings.replay_file
        while not self._stop.is_set():
            await asyncio.sleep(SNAPSHOT_EVERY)
            try:
                rows = STORE.snapshot()
                if not rows:
                    continue
                payload = {
                    "ts": time.time(),
                    "mode": "snapshot",
                    "rows": rows[:2000],
                    "overview": STORE.overview(),
                }
                with open(path, "w", encoding="utf-8") as fh:
                    json.dump(payload, fh, separators=(",", ":"))
                log.info("[%s..] snapshot dumped: %d rows -> %s", self.cfg.label, len(payload["rows"]), path)
            except Exception as e:  # noqa: BLE001
                log.debug("snapshot dump failed: %s", e)


# --------------------------------------------------------------------------
# HTTP-хелперы (синхронные, для тред-пула)
# --------------------------------------------------------------------------
def _get_json(url: str, timeout: float = 8.0):
    req = urllib.request.Request(url, headers={"User-Agent": "crypto-screener/0.1"})
    with urllib.request.urlopen(req, timeout=timeout) as r:  # noqa: S310
        return json.loads(r.read().decode("utf-8"))


def _f(x) -> Optional[float]:
    try:
        if x in (None, ""):
            return None
        v = float(x)
        return v if v == v else None  # отбрасываем NaN
    except (TypeError, ValueError):
        return None


def _find_last(tickers: dict, base: str) -> Optional[float]:
    for q in ("USDT", "USDC", "USD"):
        for suffix in (f"{base}/{q}", f"{base}/{q}:{q}"):
            t = tickers.get(suffix)
            if t and t.get("last"):
                return float(t["last"])
    return None


# --------------------------------------------------------------------------
# Оркестрация всех бирж
# --------------------------------------------------------------------------
class CollectorHub:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.collectors: list[ExchangeCollector] = []
        self.tasks: list[asyncio.Task] = []

    async def start(self) -> None:
        if not self.settings.exchanges:
            log.warning("no exchanges enabled")
            return
        for cfg in self.settings.exchanges:
            c = ExchangeCollector(cfg, self.settings)
            self.collectors.append(c)
            self.tasks.append(asyncio.create_task(c.run(), name=f"hub:{cfg.id}"))
        log.info("collector hub started: %s", ", ".join(c.cfg.label for c in self.collectors))

    def find(self, exchange_id: str, market_type: str) -> Optional[ExchangeCollector]:
        """
        Коллектор по id+рынок или по лейблу+рынок.

        Лейбл теперь общий для спота и свопа одной биржи («Binance»), поэтому
        поиск по одному лейблу неоднозначен — рынок обязателен.
        """
        for c in self.collectors:
            if c.cfg.market != market_type:
                continue
            if c.cfg.id == exchange_id or c.cfg.label == exchange_id:
                return c
        # запасной вариант: рынок не совпал (биржа подключена только одним рынком)
        for c in self.collectors:
            if c.cfg.id == exchange_id or c.cfg.label == exchange_id:
                return c
        return None

    async def fetch_candles(self, exchange_id: str, market_type: str,
                            symbol: str, tf: str, limit: int) -> list:
        c = self.find(exchange_id, market_type)
        if c is None:
            return []
        return await c.fetch_candles(symbol, tf, limit)

    async def stop(self) -> None:
        for c in self.collectors:
            await c.stop()
        await asyncio.gather(*self.tasks, return_exceptions=True)
