"""
HTTP/WebSocket API и точка входа приложения.

REST — снимки по запросу (таблицы, плотности, детали инструмента, CSV-экспорт).
WS   — push-стрим: клиент присылает свои фильтры, сервер раз в push_interval
       отдаёт только то, что попало в выборку, а не весь рынок целиком.
"""
from __future__ import annotations

import asyncio
import csv
import io
import json
import logging
import time
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any, Optional

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from starlette.requests import Request

from . import filters as F
from .metrics import TF_SECONDS, normalize_candle_volume, resample
from .alerts import AlertEngine, get_engine, init_engine
from .config import SETTINGS
from .focus import clamp_interval, clamp_limit, get_focus, init_focus
from .state import STORE

# пороги детекции спайков берём из конфига, а не из дефолтов метрик
STORE.spike_vol_ratio = SETTINGS.volume_spike_ratio
STORE.spike_tr_ratio = SETTINGS.trades_spike_ratio

log = logging.getLogger("api")
WEB_DIR = Path(__file__).resolve().parent.parent / "web"


# --------------------------------------------------------------------------
# Выборки
# --------------------------------------------------------------------------
# Кэш сериализованных строк. build_rows() обходит ВСЕ символы и строит словари;
# при 10 000+ инструментов это десятки миллисекунд CPU, а вызывается она на
# каждый WS-push (раз в секунду) и на каждый REST-запрос. Без кэша event loop
# оказывался забит сериализацией, и запросы свечей (/api/grid, /api/candles)
# голодали до видимости «висит». TTL=1 c: свежее, чем период push, не нужно.
_ROWS_CACHE: dict[str, tuple[float, list[dict]]] = {}
ROWS_CACHE_TTL = 1.0


def build_rows(with_densities: bool = False, ttl: float = ROWS_CACHE_TTL) -> list[dict]:
    key = "dens" if with_densities else "plain"
    hit = _ROWS_CACHE.get(key)
    now = time.time()
    if hit and now - hit[0] < ttl:
        return hit[1]
    rows = []
    for st in STORE.all():
        if st.last <= 0:
            continue
        rows.append(st.to_row(with_densities=with_densities))
    _ROWS_CACHE[key] = (now, rows)
    return rows


def select(query: dict[str, Any], with_densities: bool = False,
           restrict: Optional[set] = None) -> tuple[list[dict], dict]:
    """
    Фильтрация + сортировка + пагинация. Единая точка для REST и WS.

    restrict — набор ключей, за который нельзя выходить (фокус-режим: пуш
    отдаёт только те монеты, которые реально стримятся и рисуются).
    """
    params = F.parse_params(query)
    needs_dens = with_densities or bool(params.get("dens"))
    rows = build_rows(with_densities=needs_dens)
    if restrict is not None:
        rows = [r for r in rows if r["k"] in restrict]
    dup = F.base_universe(rows) if params.get("unique") else None
    rows = F.apply_filters(rows, params, dup)

    sort = str(query.get("sort", "vol"))
    desc = str(query.get("desc", "1")) not in {"0", "false", "no"}
    rows = F.sort_rows(rows, sort, desc)

    try:
        limit = max(1, min(int(query.get("limit", 200)), 5000))
    except (TypeError, ValueError):
        limit = 200

    total = len(rows)
    meta = {"total": total, "sort": sort, "desc": desc, "limit": limit, "universe": len(STORE)}
    if restrict is not None:
        meta["focus"] = True
        meta["focus_count"] = len(restrict)
    return rows[:limit], meta


def density_table(query: dict[str, Any], limit: int = 200) -> list[dict]:
    """Топ крупных лимитных плотностей по всему рынку (отдельный раздел UI)."""
    min_usd = float(query.get("min_usd") or SETTINGS.big_density_usd)
    ex = query.get("ex") or ""
    side = query.get("side") or ""
    out: list[dict] = []
    for st in STORE.all():
        if not st.big_densities or st.last <= 0:
            continue
        if ex and st.exchange_label != ex and st.exchange != ex:
            continue
        for d in st.big_densities:
            if d.quote < min_usd:
                continue
            if side and d.side != side:
                continue
            out.append({
                "k": st.key, "s": st.symbol, "exl": st.exchange_label, "mt": st.market_type,
                "p": d.price, "q": round(d.quote, 2), "base": round(d.base, 4),
                "sd": d.side, "d": round(d.dist_pct, 3), "n": d.n_orders,
                "last": st.last, "chg": round(st.change_pct, 2), "vol": round(st.vol24_usd, 2),
            })
    out.sort(key=lambda r: r["q"], reverse=True)
    return out[:limit]


CANDLES_FETCH_TIMEOUT = 8.0   # сек: сколько ждём свечи с биржи прежде чем отдать пустоту


async def _candles_with_timeout(hub, st, tf: str, limit: int) -> list:
    """
    Свечи с жёстким таймаутом.

    Без него медленная биржа (Gate ~19 c на тяжёлые вызовы) или забитый event
    loop превращали /api/candles и /api/grid в вечно висящий запрос: фронтенд
    показывал «загрузка свечей…» бесконечно. Лучше отдать пустой ответ и
    понятный статус, чем держать соединение открытым.
    """
    try:
        return await asyncio.wait_for(
            hub.fetch_candles(st.exchange, st.market_type, st.symbol, tf, limit),
            timeout=CANDLES_FETCH_TIMEOUT)
    except asyncio.TimeoutError:
        log.warning("свечи %s %s: таймаут %.0f c — отдаём пустоту", st.key, tf,
                    CANDLES_FETCH_TIMEOUT)
        return []


def meta_exchanges() -> tuple[list[str], dict[str, dict]]:
    """
    Биржи и их атрибуты для UI, сгруппированные по ЛЕЙБЛУ (имени биржи).

    Лейбл общий для спота и свопа одной биржи: в интерфейсе (как в оригинале)
    чипс выбирает биржу, а рынок переключается отдельным тумблером
    «Фьючерсы / Спот». Поэтому на лейбл приходится список рынков.

    ВАЖНО про семантику `markets`: это рынки, для которых есть КОЛЛЕКТОР
    (то есть куда можно маршрутизировать запрос свечей/сетки). Данные в
    хранилище могут содержать и другие рынки (например, replay-снапшот,
    записанный с более широким профилем) — они видны в таблицах, но тумблер
    не должен предлагать рынок, который нечем обслуживать.

    Источники объединяются: конфиг (что подключено) + хранилище (что реально
    пришло). Иначе в replay списки расходились: чипсы по одному источнику,
    DEX-метки по другому.
    """
    by_label: dict[str, dict] = {}
    for e in SETTINGS.exchanges:
        info = by_label.setdefault(e.label, {
            "ids": {}, "dex": e.dex, "configured": True,
        })
        info["ids"][e.market] = e.id
        info["dex"] = info["dex"] or e.dex
    for info in by_label.values():
        info["markets"] = sorted(info["ids"])
        info["has_spot"] = "spot" in info["markets"]
        info["has_swap"] = "swap" in info["markets"]

    # биржи, которые есть только в данных (replay-снапшот с других бирж/лейблов):
    # показываем их как чипсы-фильтры, но без рынков для маршрутизации
    dex_by_label: dict[str, bool] = {}
    seen: set[str] = set()
    for st in STORE.all():
        seen.add(st.exchange_label)
        dex_by_label[st.exchange_label] = dex_by_label.get(st.exchange_label, False) or st.dex
    for lab in seen:
        if lab in by_label:
            by_label[lab]["dex"] = by_label[lab]["dex"] or dex_by_label.get(lab, False)
            continue
        by_label[lab] = {"ids": {}, "dex": dex_by_label.get(lab, False),
                         "configured": False, "markets": [],
                         "has_spot": False, "has_swap": False}
    return sorted(by_label), by_label


def rows_to_csv(rows: list[dict]) -> str:
    if not rows:
        return ""
    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=list(rows[0].keys()))
    w.writeheader()
    for r in rows:
        w.writerow({k: (json.dumps(v, ensure_ascii=False) if isinstance(v, (dict, list)) else v)
                    for k, v in r.items()})
    return buf.getvalue()


# --------------------------------------------------------------------------
# Жизненный цикл
# --------------------------------------------------------------------------
@asynccontextmanager
async def lifespan(app: FastAPI):
    engine = init_engine(
        cooldown=SETTINGS.alert_cooldown,
        telegram_token=SETTINGS.telegram_token,
        telegram_chat_id=SETTINGS.telegram_chat_id,
    )
    focus = init_focus(SETTINGS)
    app.state.focus = focus
    tasks = [
        asyncio.create_task(engine.telegram_worker(), name="tg-worker"),
        asyncio.create_task(_alert_loop(engine), name="alert-loop"),
        asyncio.create_task(focus.start(), name="focus-loop"),
    ]

    if SETTINGS.mode == "live":
        from . import collector as _collector
        # явный PROXY_URL из настроек имеет приоритет над переменными окружения
        _collector.SETTINGS_PROXY_OVERRIDE = SETTINGS.proxy_url
        if SETTINGS.proxy_url:
            log.info("прокси из настроек: %s", SETTINGS.proxy_url)
        from .collector import CollectorHub
        hub = CollectorHub(SETTINGS)
        app.state.hub = hub
        focus.attach_hub(hub)
        await hub.start()
        log.info("live mode: %s", ", ".join(e.label for e in SETTINGS.exchanges))
        tasks.append(asyncio.create_task(_startup_health_check(hub), name="startup-check"))
    else:
        from .replay import ReplaySource
        src = ReplaySource(SETTINGS)
        app.state.replay = src
        await src.start()
        log.info("replay mode: %s", SETTINGS.replay_file)

    try:
        yield
    finally:
        for t in tasks:
            t.cancel()
        foc = getattr(app.state, "focus", None)
        if foc:
            await foc.stop()
        hub = getattr(app.state, "hub", None)
        if hub:
            await hub.stop()
        rep = getattr(app.state, "replay", None)
        if rep:
            await rep.stop()
        await asyncio.gather(*tasks, return_exceptions=True)


async def _startup_health_check(hub) -> None:
    """
    Если ни одна биржа не подключилась, сервер продолжает работать пустым —
    снаружи это выглядит как «скринер сломался». Сообщаем явно и подсказываем,
    что проверить, вместо того чтобы оставлять пользователя гадать.
    """
    await asyncio.sleep(30)
    if len(STORE) > 0:
        failed = [k for k, v in STORE.exchange_status.items() if v.get("state") == "error"]
        if failed:
            log.warning("не подключились: %s (остальные работают)", ", ".join(failed))
        return

    log.error("=" * 74)
    log.error("НИ ОДНА БИРЖА НЕ ПОДКЛЮЧИЛАСЬ — данных нет, интерфейс будет пустым.")
    log.error("")
    log.error("Причины по убыванию вероятности:")
    log.error("  1. Исходящий трафик блокируется: файрвол, антивирус, корпоративный")
    log.error("     прокси. Падают сразу все биржи — это главный признак.")
    log.error("  2. Биржи блокируют ваш регион (в логе выше будут 403/451/restricted).")
    log.error("     Нужен VPN, либо прокси:")
    log.error('       PowerShell:  $env:HTTPS_PROXY="http://127.0.0.1:1080"; python run.py')
    log.error("       cmd:         set HTTPS_PROXY=http://127.0.0.1:1080 && python run.py")
    log.error("  3. TLS-сертификаты (часто на Windows):  pip install -U certifi")
    log.error("")
    log.error("Точную причину покажет диагностика по слоям (DNS / TLS / HTTP / ccxt):")
    log.error("       python doctor.py")
    log.error("")
    log.error("Посмотреть интерфейс без бирж можно на записанном снимке рынка:")
    log.error("       PowerShell:  $env:MODE='replay'; python run.py")
    log.error("=" * 74)


async def _alert_loop(engine: AlertEngine) -> None:
    await asyncio.sleep(5)
    while True:
        try:
            rows = build_rows()
            if rows:
                await engine.evaluate(rows)
        except Exception as e:  # noqa: BLE001
            log.warning("alert loop: %s", str(e)[:200])
        await asyncio.sleep(1.0)


app = FastAPI(title="Crypto Screener (self-hosted)", version="0.1.0", lifespan=lifespan)


# --------------------------------------------------------------------------
# REST: данные
# --------------------------------------------------------------------------
@app.get("/api/overview")
async def api_overview():
    return STORE.overview()


@app.get("/api/meta")
async def api_meta():
    """Всё, что нужно фронту для построения UI, одним запросом."""
    return {
        "filters": F.catalog(),
        "sorts": F.sort_catalog(),
        "presets": F.preset_catalog(),
        "exchanges": meta_exchanges()[0],
        "exchange_info": meta_exchanges()[1],
        "market_types": ["spot", "swap"],
        "quotes": SETTINGS.quote_assets,
        "mode": SETTINGS.mode,
        "big_density_usd": SETTINGS.big_density_usd,
        "push_interval": SETTINGS.push_interval,
        "tf": list(SETTINGS.tf_seconds),
        "focus": get_focus().state(),
    }


@app.get("/api/screener")
async def api_screener(request: Request):
    """Основная выборка. Все фильтры — обычные query-параметры (см. /api/meta)."""
    qp = dict(request.query_params)
    rows, meta = select(qp, with_densities=qp.get("dens") == "1")
    return {"rows": rows, "meta": meta}


@app.get("/api/screener.csv")
async def api_screener_csv(request: Request):
    rows, _ = select(dict(request.query_params))
    body = rows_to_csv(rows)
    return Response(body, media_type="text/csv; charset=utf-8",
                    headers={"Content-Disposition": f'attachment; filename="screener-{int(time.time())}.csv"'})


@app.get("/api/densities")
async def api_densities(request: Request):
    qp = dict(request.query_params)
    try:
        limit = max(1, min(int(qp.get("limit", 200)), 2000))
    except (TypeError, ValueError):
        limit = 200
    return {"rows": density_table(qp, limit),
            "threshold": float(qp.get("min_usd") or SETTINGS.big_density_usd)}


@app.get("/api/symbol")
async def api_symbol(key: str):
    st = STORE.get(key)
    if not st:
        return JSONResponse({"error": f"инструмент не найден: {key}"}, status_code=404)
    row = st.to_row(with_densities=True)
    row["spark"] = st.sparkline(120)
    row["book"] = {
        # уровни уже нормализованы в apply_book(), но читаем защитно:
        # вдруг биржа подсунет лишние поля (MEXC отдаёт [price, amount, count])
        "bids": [[float(x[0]), float(x[1])] for x in (st.book or {}).get("bids", [])[:25]],
        "asks": [[float(x[0]), float(x[1])] for x in (st.book or {}).get("asks", [])[:25]],
    }
    row["densities"] = [
        {"p": d.price, "q": round(d.quote, 2), "sd": d.side, "d": round(d.dist_pct, 3), "n": d.n_orders}
        for d in st.densities[:30]
    ]
    row["spikes"] = [
        {"kind": s.kind, "ratio": round(s.ratio, 2), "value": round(s.value, 2),
         "base": round(s.base, 2), "age": int(s.age), "ts": s.ts}
        for s in list(st.spikes)[-20:][::-1]
    ]
    row["history"] = [[round(ts, 1), p] for ts, p in st.price_hist.tail(600)]
    return row


@app.get("/api/candles")
async def api_candles(request: Request):
    """
    Свечи для графика инструмента.

    live   → заказываем у коллектора нужной биржи (там кэш на CANDLES_TTL)
    replay → ресэмплим синтетические 1m-свечи в запрошенный таймфрейм

    Заодно отдаём плотности и спайки — график рисует их поверх свечей.
    """
    qp = dict(request.query_params)
    key = qp.get("key") or ""
    tf = qp.get("tf") or "15m"
    if tf not in TF_SECONDS:
        return JSONResponse({"error": f"неподдерживаемый таймфрейм {tf!r}",
                             "supported": sorted(TF_SECONDS)}, status_code=400)
    try:
        limit = max(20, min(int(qp.get("limit", 300)), 1000))
    except (TypeError, ValueError):
        limit = 300

    st = STORE.get(key)
    if not st:
        return JSONResponse({"error": f"инструмент не найден: {key}"}, status_code=404)

    candles: list = []
    hub = getattr(app.state, "hub", None)
    if hub is not None:
        candles = await _candles_with_timeout(hub, st, tf, limit)
    if not candles and st.ohlcv:
        # replay (или биржа не ответила) — собираем из накопленных 1m-свечей
        candles = resample(st.ohlcv, TF_SECONDS[tf])[-limit:]

    candles = normalize_candle_volume(candles, st.inverse, st.contract_size,
                                      st.ohlcv_vol_in_contracts)
    return {
        "key": key, "symbol": st.symbol, "exchange": st.exchange_label,
        "market_type": st.market_type, "tf": tf, "tf_seconds": TF_SECONDS[tf],
        "candles": candles,
        "last": st.last, "bid": st.bid, "ask": st.ask, "chg": round(st.change_pct, 3),
        "natr": round(st.natr, 3) if st.natr else None,
        "densities": [
            {"p": d.price, "q": round(d.quote, 2), "sd": d.side, "d": round(d.dist_pct, 3)}
            for d in st.densities[:25]
        ],
        "spikes": [{"ts": s.ts, "kind": s.kind, "ratio": round(s.ratio, 2)}
                   for s in list(st.spikes)[-40:]],
        "source": "exchange" if hub is not None and candles else "resampled",
    }


@app.get("/api/grid")
async def api_grid(request: Request):
    """
    Данные для сетки графиков (многоэкранный режим, как в оригинале).

    Один запрос возвращает свечи сразу для N инструментов выбранной биржи и
    рынка — иначе сетка из 9 ячеек делала бы 9 отдельных запросов каждые
    несколько секунд и упиралась в rate-limit биржи.

    Параметры: ex (лейбл биржи), mt (spot|swap), tf, n (число ячеек), sort.

    Фокус-режим меняет источник ячеек: вместо «топ по объёму среди всего,
    что случайно попало в горячий набор» берутся монеты текущего отбора —
    они гарантированно стримятся, и свечи для них биржа отдаёт быстро.
    """
    qp = dict(request.query_params)
    focus = get_focus()
    ex = qp.get("ex") or ""
    mt = qp.get("mt") or "swap"
    tf = qp.get("tf") or "5m"
    if tf not in TF_SECONDS:
        return JSONResponse({"error": f"неподдерживаемый tf {tf!r}",
                             "supported": sorted(TF_SECONDS)}, status_code=400)
    try:
        n = max(1, min(int(qp.get("n", 9)), 25))
        limit = max(20, min(int(qp.get("limit", 200)), 400))
    except (TypeError, ValueError):
        n, limit = 9, 200

    # отбираем топ-N символов нужной биржи и рынка; build_rows() вызываем ОДИН
    # раз — это самая дорогая операция запроса (сериализация всех символов)
    all_rows = build_rows()
    available = sorted({x["exl"] for x in all_rows if x["mt"] == mt})
    focus_on = focus.enabled and focus.spec.mt == mt and (
        not ex or ex in (focus.spec.ex, "") or focus.spec.ex in ("", ex))
    if focus_on and focus.keys:
        idx = {r["k"]: r for r in all_rows if r["mt"] == mt}
        # порядок = порядок отбора (он уже отсортирован по фильтру пользователя)
        rows = [idx[k] for k in focus.keys if k in idx][:n]
        ex = ex or focus.spec.ex
    else:
        rows = [r for r in all_rows if (not ex or r["exl"] == ex) and r["mt"] == mt]
        rows = F.sort_rows(rows, qp.get("sort", "vol"), True)[:n]

    hub = getattr(app.state, "hub", None)
    cells = []
    for r in rows:
        st = STORE.get(r["k"])
        candles: list = []
        if hub is not None and st:
            candles = await _candles_with_timeout(hub, st, tf, limit)
        if not candles and st and st.ohlcv:
            candles = resample(st.ohlcv, TF_SECONDS[tf])[-limit:]
        candles = normalize_candle_volume(candles, st.inverse, st.contract_size,
                                          st.ohlcv_vol_in_contracts) if (candles and st) else candles
        cells.append({
            "k": r["k"], "s": r["s"], "b": r["b"], "exl": r["exl"], "mt": r["mt"],
            "dex": r.get("dex", False),
            "last": r["last"], "chg": r["chg"], "vol": r["vol"],
            "natr": r["natr"], "spike": r["spike"],
            "candles": candles,
            "candles_ok": bool(candles),
        })
    return {"cells": cells, "tf": tf, "tf_seconds": TF_SECONDS[tf], "mt": mt,
            "ex": ex, "available_exchanges": available,
            "total": len(rows),
            "focus": {"on": bool(focus_on and focus.keys), "count": len(focus.keys),
                      "limit": focus.spec.limit, "interval": focus.spec.interval,
                      "next_in": round(max(0.0, focus.next_at - time.time()), 1)
                      if focus.enabled else None,
                      "note": focus.note if focus_on else ""}}


# --------------------------------------------------------------------------
# REST: фокус-режим (одна биржа + один рынок + top-N по фильтру)
# --------------------------------------------------------------------------
def _focus_payload(data: dict) -> dict:
    """Нормализация тела запроса: мусор на входе не должен ломать отбор."""
    out: dict[str, Any] = {}
    if "ex" in data:
        out["ex"] = str(data.get("ex") or "").strip()
    if data.get("mt") in ("spot", "swap"):
        out["mt"] = str(data["mt"])
    if "limit" in data:
        out["limit"] = clamp_limit(data.get("limit"))
    if "interval" in data:
        out["interval"] = clamp_interval(data.get("interval"))
    if "sort" in data and str(data.get("sort")) in F.SORT_FIELDS:
        out["sort"] = str(data["sort"])
    if "desc" in data:
        out["desc"] = data.get("desc")
    if "pause_others" in data:
        out["pause_others"] = bool(data.get("pause_others"))
    if "dedupe_base" in data:
        out["dedupe_by_base"] = bool(data.get("dedupe_base"))
    q = data.get("query")
    if isinstance(q, dict):
        # те же параметры, что принимает /api/screener — фильтр один на всё
        out["params"] = F.parse_params({str(k): str(v) for k, v in q.items()
                                        if v not in (None, "")})
    return out


@app.get("/api/focus")
async def api_focus_get():
    """Текущий отбор: какие монеты стримятся, когда следующая перепроверка."""
    return get_focus().state()


@app.post("/api/focus")
async def api_focus_set(request: Request):
    """
    Включить/перенастроить фокус-режим.

    Тело: {ex, mt, limit, interval, sort, desc, pause_others, query:{...фильтры}}
    Отбор пересчитывается СРАЗУ, не дожидаясь следующего тика, иначе после
    нажатия кнопки пользователь 15 секунд смотрел бы на пустую сетку.
    """
    focus = get_focus()
    try:
        data = await request.json()
    except Exception:  # noqa: BLE001
        return JSONResponse({"error": "нужен JSON в теле запроса"}, status_code=400)
    if not isinstance(data, dict):
        return JSONResponse({"error": "тело запроса должно быть объектом"}, status_code=400)
    st = await focus.update(**_focus_payload(data))
    if not st["ex"]:
        return JSONResponse({**st, "error": "нет подключённой биржи для фокус-режима"},
                            status_code=409)
    return st


@app.delete("/api/focus")
async def api_focus_off():
    """Выключить: возвращаемся к полному горячему набору всех бирж."""
    return await get_focus().disable()


@app.get("/api/heatmap")
async def api_heatmap(request: Request):
    """
    Данные для «карты рынка»: плитка = инструмент, размер = объём, цвет = изменение.
    Отдаём компактными массивами — так в 5-8 раз меньше трафика, чем JSON-объектами.
    """
    qp = dict(request.query_params)
    params = F.parse_params(qp)
    rows = build_rows()
    dup = F.base_universe(rows) if params.get("unique") else None
    rows = F.apply_filters(rows, params, dup)
    try:
        limit = max(1, min(int(qp.get("limit", 300)), 2000))
    except (TypeError, ValueError):
        limit = 300
    rows = F.sort_rows(rows, "vol", True)[:limit]
    tiles = [
        {
            "k": r["k"], "s": r["s"].split("/")[0], "b": r["b"], "ex": r["exl"],
            "chg": r["chg"], "vol": r["vol"], "last": r["last"],
            "spike": bool(r["spike"]), "natr": r["natr"],
        }
        for r in rows
    ]
    return {"tiles": tiles, "total": len(tiles),
            "min_vol": tiles[-1]["vol"] if tiles else 0,
            "max_vol": tiles[0]["vol"] if tiles else 0}


# --------------------------------------------------------------------------
# REST: алерты
# --------------------------------------------------------------------------
@app.get("/api/alerts")
async def api_alerts_list():
    eng = get_engine()
    return {"rules": eng.list(), "events": eng.recent(100)}


@app.post("/api/alerts")
async def api_alerts_create(request: Request):
    try:
        payload = await request.json()
    except Exception:  # noqa: BLE001
        return JSONResponse({"error": "нужен JSON в теле запроса"}, status_code=400)
    try:
        rule = get_engine().add(**payload)
    except (ValueError, KeyError, TypeError) as e:
        return JSONResponse({"error": str(e)}, status_code=400)
    return {"rule": rule.to_dict()}


@app.patch("/api/alerts/{rid}")
async def api_alerts_update(rid: str, request: Request):
    try:
        payload = await request.json()
    except Exception:  # noqa: BLE001
        payload = {}
    rule = get_engine().update(rid, **payload)
    if not rule:
        return JSONResponse({"error": "правило не найдено"}, status_code=404)
    return {"rule": rule.to_dict()}


@app.delete("/api/alerts/{rid}")
async def api_alerts_delete(rid: str):
    if not get_engine().remove(rid):
        return JSONResponse({"error": "правило не найдено"}, status_code=404)
    return {"ok": True}


# --------------------------------------------------------------------------
# WebSocket
# --------------------------------------------------------------------------
@app.websocket("/ws")
async def ws_stream(ws: WebSocket):
    await ws.accept()
    query: dict[str, Any] = {"sort": "vol", "desc": "1", "limit": "150"}
    dens_mode = False
    # base=1: клиент просит «полную базу»: он сам кормит таблицу из REST, а пуш
    # использует только для живых тиков. Тогда сужать выборку до фокус-набора
    # нельзя — иначе таблица и карта рынка схлопнутся до top-N.
    base_mode = False
    engine = get_engine()
    alert_q = engine.subscribe()
    stop = asyncio.Event()
    ready = asyncio.Event()   # выставится, когда клиент пришлёт свои фильтры

    async def reader() -> None:
        nonlocal query, dens_mode, base_mode
        try:
            while not stop.is_set():
                data = json.loads(await ws.receive_text())
                if data.get("type") == "filters":
                    query = {str(k): str(v) for k, v in (data.get("query") or {}).items()
                             if v not in (None, "")}
                    dens_mode = bool(data.get("densities"))
                    base_mode = bool(data.get("base"))
                    ready.set()
                elif data.get("type") == "ping":
                    await ws.send_text(json.dumps({"type": "pong", "ts": time.time()}))
        except WebSocketDisconnect:
            pass
        except Exception:  # noqa: BLE001
            pass
        finally:
            stop.set()

    async def pusher() -> None:
        """Шлёт выборку с фиксированным интервалом; медленный клиент отваливается сам."""
        interval = SETTINGS.push_interval
        # Ждём первые фильтры клиента, иначе ушёл бы батч с дефолтной выборкой —
        # клиенту пришлось бы его выбросить (и в UI мелькали «не те» строки).
        # Таймаут — чтобы клиент без filters тоже получил данные.
        try:
            await asyncio.wait_for(ready.wait(), timeout=3.0)
        except asyncio.TimeoutError:
            pass
        try:
            while not stop.is_set():
                t0 = time.time()
                foc = getattr(app.state, "focus", None)
                focus_on = bool(foc and foc.enabled)
                restrict = foc.key_set if (focus_on and not base_mode) else None
                rows, meta = select(query, with_densities=dens_mode, restrict=restrict)
                if focus_on and base_mode:
                    # выборка полная, но число стримов клиенту показывать нужно
                    meta["focus_count"] = len(foc.key_set)
                await ws.send_text(json.dumps(
                    {"type": "rows", "rows": rows, "meta": meta,
                     "overview": STORE.overview(), "ts": time.time()},
                    separators=(",", ":")))
                await asyncio.sleep(max(0.1, interval - (time.time() - t0)))
        except Exception:  # noqa: BLE001
            pass
        finally:
            stop.set()

    async def alerter() -> None:
        try:
            while not stop.is_set():
                try:
                    ev = await asyncio.wait_for(alert_q.get(), timeout=1.0)
                except asyncio.TimeoutError:
                    continue
                await ws.send_text(json.dumps({"type": "alert", "alert": ev}, separators=(",", ":")))
        except Exception:  # noqa: BLE001
            pass
        finally:
            stop.set()

    tasks = [asyncio.create_task(reader()), asyncio.create_task(pusher()), asyncio.create_task(alerter())]
    try:
        await ws.send_text(json.dumps({"type": "hello", "mode": SETTINGS.mode, "ts": time.time()}))
        await stop.wait()
    finally:
        stop.set()
        engine.unsubscribe(alert_q)
        for t in tasks:
            t.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)


# --------------------------------------------------------------------------
# Фронтенд
# --------------------------------------------------------------------------
@app.get("/")
async def index():
    idx = WEB_DIR / "index.html"
    if idx.exists():
        return FileResponse(idx)
    return JSONResponse({"hint": "frontend не найден; API доступно на /api/*"}, status_code=200)


@app.get("/app.js")
async def app_js():
    return FileResponse(WEB_DIR / "app.js", media_type="application/javascript")


@app.get("/chart.js")
async def chart_js():
    return FileResponse(WEB_DIR / "chart.js", media_type="application/javascript")


@app.get("/style.css")
async def style_css():
    return FileResponse(WEB_DIR / "style.css", media_type="text/css")


@app.get("/healthz")
async def healthz():
    ov = STORE.overview()
    return {"ok": ov["symbols"] > 0 or SETTINGS.mode == "replay", **{k: ov[k] for k in ("symbols", "volume_usd", "uptime")},
            "mode": SETTINGS.mode, "exchanges": list(ov["status"].keys())}


if WEB_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(WEB_DIR)), name="static")


def create_app() -> FastAPI:
    return app
